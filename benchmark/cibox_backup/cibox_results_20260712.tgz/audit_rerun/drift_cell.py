# One fresh-process drift sample: score D4 Trace_Filtered + Alpha+ with M1g
# (v2.6-mle, 5 iterations, 1000 traces), print one JSON line. PYTHONHASHSEED=0
# is set by the caller BEFORE interpreter start, matching the benchmark runs.
import os, sys, time, json, glob
sys.path.insert(0, os.path.expanduser("~/genbench"))
import pm4py
from pm4py.objects.log.importer.xes import importer as xes_importer
from HybridGen.algorithm.v26 import calculate_gen_shadow_stable

LOG = os.path.expanduser("~/genbench/data/BPI-Challenge_2018/BPI Challenge 2018.xes.gz")
t0 = time.time()
log = pm4py.convert_to_event_log(pm4py.read_xes(LOG))
load_s = time.time() - t0

out = {"load_s": round(load_s, 1), "pid": os.getpid()}
for miner in ["Trace_Filtered", "Alpha+"]:
    hits = (glob.glob(os.path.expanduser(f"~/genbench/benchmark/models/*/{miner}.pnml")))
    hit = next((h for h in hits if "2018" in h or "D4" in h), None)
    if not hit:
        out[miner] = {"error": f"no PNML found among {hits[:3]}"}
        continue
    net, im, fm = pm4py.read_pnml(hit)
    t = time.time()
    r = calculate_gen_shadow_stable(log, net, im, fm, 1000, iterations=5,
                                    successor_weighting="mle")
    out[miner] = {"mean": round(r["mean"], 6), "std": round(r["std"], 6),
                  "raw": [round(x, 6) for x in r["raw_scores"]],
                  "runtime_s": round(time.time() - t, 1), "pnml": hit}
print(json.dumps(out), flush=True)
