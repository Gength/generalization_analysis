# BPI2017 subsample runtime sweep (runs on cibox, one machine, one convention).
# Times each metric GIVEN a discovered model ("model in hand"), consistently.
# Metrics: ShadowGen 5-iter, ShadowGen 1-iter, PM4Py (M2), Bootstrap (M6adapted).
import os, sys, time, json, random
import numpy as np
HOME = os.path.expanduser("~")
sys.path.insert(0, f"{HOME}/genbench")
sys.path.insert(0, f"{HOME}/genbench/benchmark")
sys.path.insert(0, f"{HOME}/genbench/benchmark/bridges")
import pm4py
from pm4py.objects.log.importer.xes import importer as xes_importer
from pm4py.algo.evaluation.generalization import algorithm as gen_eval
from pm4py.algo.evaluation.replay_fitness import algorithm as rf_eval
from HybridGen.algorithm.v26 import calculate_gen_shadow_stable
from miners import MINERS
from bsgen_eval import log_sample_with_breeding, dedup

OUT = f"{HOME}/rt_sweep"
SIZES = [100, 1000, 10000, 100000, 1000000]
MINER_NAMES = ["Alpha", "Alpha+", "Heuristics", "Heuristics_Strict",
               "Inductive_Strict", "Inductive_Infrequent", "Trace_Filtered", "Flower"]

def t_m1(log, net, im, fm, iters):
    t = time.time()
    calculate_gen_shadow_stable(log, net, im, fm, 1000, iterations=iters, successor_weighting="mle")
    return time.time() - t

def t_m2(log, net, im, fm):
    t = time.time(); gen_eval.apply(log, net, im, fm); return time.time() - t

def t_m6a(log, net, im, fm):
    random.seed(42); np.random.seed(42)
    t = time.time()
    for _ in range(10):  # N_BOOTSTRAP
        uniq = dedup(log_sample_with_breeding(log, 10, 200, 2, 1.0))  # gens,sample,k,p
        rf_eval.apply(uniq, net, im, fm, variant=rf_eval.Variants.TOKEN_BASED)
    return time.time() - t

METRICS = [("M1g_5it", lambda l, n, i, f: t_m1(l, n, i, f, 5)),
           ("M1g_1it", lambda l, n, i, f: t_m1(l, n, i, f, 1)),
           ("M2",       lambda l, n, i, f: t_m2(l, n, i, f)),
           ("M6adapted", lambda l, n, i, f: t_m6a(l, n, i, f))]

results = {}
for sz in SIZES:
    xes = f"{OUT}/bpi2017_sub{sz}.xes"
    t0 = time.time(); log = xes_importer.apply(xes)
    events = sum(len(tr) for tr in log)
    print(f"[sz {sz}] loaded {len(log)} traces / {events} events ({time.time()-t0:.1f}s)", flush=True)
    nets = {}
    for mn in MINER_NAMES:
        if mn not in MINERS:
            print(f"  {mn}: not in MINERS", flush=True); continue
        try:
            nets[mn] = MINERS[mn](log)
        except Exception as e:
            print(f"  {mn}: discover FAIL {type(e).__name__}: {e}", flush=True)
    per = {k: [] for k, _ in METRICS}
    for mn, (net, im, fm) in nets.items():
        for key, fn in METRICS:
            try:
                rt = fn(log, net, im, fm); per[key].append(rt)
            except Exception as e:
                print(f"  {mn} {key}: FAIL {type(e).__name__}: {e}", flush=True)
    row = {"events": events, "n_traces": len(log)}
    for key, _ in METRICS:
        v = per[key]
        row[key] = {"median": float(np.median(v)), "min": float(min(v)),
                    "max": float(max(v)), "n": len(v)} if v else None
        if v:
            print(f"  {key}: median {np.median(v):.3f}s (n={len(v)})", flush=True)
    results[str(sz)] = row
    json.dump(results, open(f"{OUT}/rt_sweep_results.json", "w"), indent=2)  # incremental
    print(f"[sz {sz}] done, saved", flush=True)

print("SWEEP_DONE", flush=True)
