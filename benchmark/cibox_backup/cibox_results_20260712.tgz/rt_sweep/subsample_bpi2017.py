# Uniform trace subsample of BPI2017 to target event counts (runs on cibox).
import os, random, time
import pm4py
from pm4py.objects.log.obj import EventLog
from pm4py.objects.log.exporter.xes import exporter as xes_exporter

SRC = os.path.expanduser("~/genbench/data/BPI-Challenge_2017/BPI Challenge 2017.xes.gz")
OUT = os.path.expanduser("~/rt_sweep")
os.makedirs(OUT, exist_ok=True)

t = time.time()
log = pm4py.convert_to_event_log(pm4py.read_xes(SRC))
tot_ev = sum(len(tr) for tr in log)
print(f"loaded {len(log)} traces / {tot_ev} events in {time.time()-t:.1f}s", flush=True)

random.seed(42)
idx = list(range(len(log)))
random.shuffle(idx)

for tgt in [100, 1000, 10000, 100000, 1000000]:
    sub, ev = [], 0
    for i in idx:
        sub.append(log[i]); ev += len(log[i])
        if ev >= tgt:
            break
    p = f"{OUT}/bpi2017_sub{tgt}.xes"
    xes_exporter.apply(EventLog(sub), p)
    print(f"sub{tgt}: {len(sub)} traces / {ev} events -> {p}", flush=True)

print("SUBSAMPLES_DONE", flush=True)
