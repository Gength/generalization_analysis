# Independent re-run of M2 (PM4Py gen) and M7 (SpeciAL) on cibox, model-in-hand,
# true wall time (2h safety cap), to verify/replace partner-provenance runtimes
# and scores. Uniform special4pm 0.1.3. Incremental JSON.
import os, sys, time, json, signal
from functools import partial
import numpy as np
H = os.path.expanduser("~/genbench")
sys.path.insert(0, H); sys.path.insert(0, H + "/benchmark")
import pm4py
from pm4py.objects.petri_net.importer import importer as pnml_importer
from pm4py.algo.evaluation.generalization import algorithm as gen_eval
from special4pm.estimation import SpeciesEstimator
from special4pm.species import retrieve_species_n_gram, retrieve_species_trace_variant
from special4pm.simulation.simulation import simulate_model

LOGS = {
 'D1': 'data/Sepsis Cases - Event Log_1_all/Sepsis Cases - Event Log.xes.gz',
 'D2': 'data/BPI-Challenge_2013/Incident_Management_Log.xes.gz',
 'D3': 'data/BPI-Challenge_2017/BPI Challenge 2017.xes.gz',
 'D4': 'data/BPI-Challenge_2018/BPI Challenge 2018.xes.gz',
 'D5': 'data/BPI-Challenge_2019/BPI_Challenge_2019.xes.gz',
}
MINERS = ['Alpha','Alpha+','Heuristics','Heuristics_Strict','Inductive_Infrequent','Inductive_Strict','Trace_Filtered','Flower']
OUT = os.path.expanduser("~/m2m7_rerun"); os.makedirs(OUT, exist_ok=True)
CAP = 7200  # 2h safety per cell (well above the 1h protocol, to measure true time)

def _sp_estimator():
    est = SpeciesEstimator(step_size=None, d0=False, d1=False, d2=False, c0=True, c1=True)
    for sp in ['1-gram','2-gram','3-gram']:
        est.register(sp, partial(retrieve_species_n_gram, n=int(sp[0])))
    est.register('tv', retrieve_species_trace_variant)
    return est

def orig_c1(log):
    est = _sp_estimator(); est.apply(log, verbose=False)
    return {sp: est.metrics[sp]['incidence_c1'][-1] for sp in ['1-gram','2-gram','3-gram','tv']
            if 'incidence_c1' in est.metrics[sp]}

class TO(Exception): pass
def _alarm(s, f): raise TO()
signal.signal(signal.SIGALRM, _alarm)

results = {}
for key, lp in LOGS.items():
    t = time.time()
    log = pm4py.convert_to_event_log(pm4py.read_xes(os.path.join(H, lp)))
    oc1 = orig_c1(log)
    print(f"[{key}] {len(log)} traces loaded+orig-C1 in {time.time()-t:.0f}s", flush=True)
    for mn in MINERS:
        p = f"{H}/benchmark/models/{key}/{mn}.pnml"
        row = {"n_traces": len(log)}
        if not os.path.exists(p):
            row["error"] = "no pnml"; results[f"{key}__{mn}"] = row; continue
        net, im, fm = pnml_importer.apply(p)
        # M2
        signal.alarm(CAP); t = time.time()
        try:
            row["M2_score"] = float(gen_eval.apply(log, net, im, fm)); row["M2_s"] = round(time.time()-t, 1)
        except TO: row["M2_s"] = f">={CAP}"; row["M2_score"] = None
        except Exception as e: row["M2_err"] = str(e)[:60]; row["M2_s"] = round(time.time()-t,1)
        finally: signal.alarm(0)
        # M7
        signal.alarm(CAP); t = time.time()
        try:
            sim = simulate_model(net, im, fm, size=len(log))
            se = _sp_estimator(); se.apply(sim, verbose=False)
            sc1 = {sp: se.metrics[sp]['incidence_c1'][-1] for sp in ['1-gram','2-gram','3-gram','tv'] if 'incidence_c1' in se.metrics[sp]}
            ratios = [min(sc1[sp]/oc1[sp], 1.0) for sp in oc1 if sp in sc1 and oc1[sp] > 0]
            row["M7_score"] = float(np.mean(ratios)) if ratios else 0.0; row["M7_s"] = round(time.time()-t, 1)
        except TO: row["M7_s"] = f">={CAP}"; row["M7_score"] = None
        except Exception as e: row["M7_err"] = str(e)[:60]; row["M7_s"] = round(time.time()-t,1)
        finally: signal.alarm(0)
        results[f"{key}__{mn}"] = row
        json.dump(results, open(f"{OUT}/m2m7_rerun.json", "w"), indent=2)
        print(f"  {key} {mn:22} M2={row.get('M2_s')}s M7={row.get('M7_s')}s", flush=True)
print("M2M7_RERUN_DONE", flush=True)
