#!/bin/bash
# Stand up a user-space TF1.15 env on cibox (no sudo/docker), clone AVATAR,
# and run a 100-step timing probe on the Ryzen 9950X3D.
set -e
mkdir -p ~/av_run
cd ~
echo "=== SETUP START $(date -u +%FT%TZ) ==="

if [ ! -d ~/miniconda3 ]; then
  echo "[1] installing miniconda (user-space)"
  curl -sL https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -o ~/mc.sh
  bash ~/mc.sh -b -p ~/miniconda3
fi
source ~/miniconda3/etc/profile.d/conda.sh

if ! conda env list | grep -q av37; then
  echo "[2] creating py37 env"
  conda create -y -n av37 python=3.7 >/dev/null
fi
conda activate av37

echo "[3] installing TF1.15.2 + deps"
pip install -q tensorflow==1.15.2 numpy==1.16.3 scikit-learn==0.21.2 tqdm nltk pandas
python -c "import tensorflow as tf,numpy; print('TF',tf.__version__,'np',numpy.__version__)"

if [ ! -d ~/av_run/AVATAR ]; then
  echo "[4] cloning AVATAR"
  git clone -q https://github.com/ProminentLab/AVATAR ~/av_run/AVATAR
fi
cd ~/av_run/AVATAR

echo "[5] env-override patch"
python - <<'PY'
import io
p='avatar/training.py'; t=io.open(p,encoding='utf-8').read()
old="    npre_epochs = '100' #100\n    nadv_steps = '5000' #5000s"
if old in t:
    new=("    import os as _os\n"
         "    npre_epochs = _os.environ.get('AVATAR_NPRE_EPOCHS','100')\n"
         "    nadv_steps = _os.environ.get('AVATAR_NADV_STEPS','5000')")
    io.open(p,'w',encoding='utf-8').write(t.replace(old,new,1)); print('  patched')
else:
    print('  patch skipped (already patched or code differs)')
PY

echo "[6] variant files"
mkdir -p data/variants data/avatar/train_data data/avatar/sgans data/avatar/variants
cp ~/av_variants/sepsis_*.txt data/variants/
wc -l data/variants/sepsis_*.txt

echo "=== PROBE START $(date -u +%FT%TZ) (3 pre-epochs, 100 adv steps) ==="
AVATAR_NPRE_EPOCHS=3 AVATAR_NADV_STEPS=100 OMP_NUM_THREADS=32 \
  python -u -m avatar.training -s sepsis -j 0 -gpu 0 -n 10000 || echo "PROBE exited non-zero (timing may still be captured above)"
echo "=== PROBE END $(date -u +%FT%TZ) ==="
echo "AV_PROBE_DONE"
