/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 */
package org.processmining.plugins.neconformance.ui.simple;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.deckfour.xes.classification.XEventClass;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.ui.simple.EvaluationVisualizator;

public class AlignmentPane
extends JPanel {
    private static final long serialVersionUID = 4552315260112714479L;
    private EvaluationVisualizator evaluationVisualizator;
    private ProcessReplayModel<Transition, XEventClass, Marking> selectedReplayModel;
    private int selectedTraceIndex = -1;
    private final JList<ProcessReplayModel.ReplayMove> stepList;

    public AlignmentPane(final EvaluationVisualizator evaluationVisualizator) {
        this.setLayout(new BorderLayout());
        this.setPreferredSize(new Dimension(300, 90));
        this.evaluationVisualizator = evaluationVisualizator;
        this.stepList = new JList();
        this.stepList.setLayoutOrientation(2);
        this.stepList.setVisibleRowCount(1);
        JScrollPane scroll = new JScrollPane(this.stepList, 21, 32);
        this.add(scroll);
        this.stepList.setCellRenderer(new DefaultListCellRenderer(){
            private static final long serialVersionUID = -2745441247826070962L;

            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                ProcessReplayModel.ReplayMove move = (ProcessReplayModel.ReplayMove)((Object)value);
                String text = "";
                String traceEl = AlignmentPane.this.selectedReplayModel.getTraceElement(index) == null ? "***" : ((XEventClass)AlignmentPane.this.selectedReplayModel.getTraceElement(index)).toString();
                String modelEl = AlignmentPane.this.selectedReplayModel.getModelElement(index) == null ? "***" : ((Transition)AlignmentPane.this.selectedReplayModel.getModelElement(index)).toString();
                text = "<html>" + modelEl + "<br>" + traceEl + "<br>" + move.toString() + "</html>";
                switch (move) {
                    case BOTH_SYNCHRONOUS: {
                        c.setBackground(Color.green);
                        break;
                    }
                    case BOTH_FORCED: {
                        c.setBackground(Color.red);
                        break;
                    }
                    case LOGONLY_INSERTED: {
                        c.setBackground(Color.yellow);
                        break;
                    }
                    case MODELONLY_SKIPPED: {
                        c.setBackground(Color.pink);
                        break;
                    }
                    case MODELONLY_UNOBSERVABLE: {
                        c.setBackground(Color.gray);
                        break;
                    }
                }
                this.setText(text);
                return c;
            }
        });
        this.stepList.addListSelectionListener(new ListSelectionListener(){

            @Override
            public void valueChanged(ListSelectionEvent arg0) {
                evaluationVisualizator.notifyReplayStepSelection(AlignmentPane.this.selectedTraceIndex, AlignmentPane.this.stepList.getSelectedIndex());
            }
        });
    }

    public void notifyTraceSelection(int selectedTraceIndex) {
        this.selectedTraceIndex = selectedTraceIndex;
        this.selectedReplayModel = this.evaluationVisualizator.getResult().replayModels.get(selectedTraceIndex);
        ArrayList<ProcessReplayModel.ReplayMove> steps = new ArrayList<ProcessReplayModel.ReplayMove>();
        int step = 0;
        while (step < this.selectedReplayModel.size()) {
            ProcessReplayModel.ReplayMove type = this.selectedReplayModel.getReplayMove(step);
            steps.add(type);
            ++step;
        }
        this.stepList.setListData((ProcessReplayModel.ReplayMove[])steps.toArray(new ProcessReplayModel.ReplayMove[0]));
    }
}

