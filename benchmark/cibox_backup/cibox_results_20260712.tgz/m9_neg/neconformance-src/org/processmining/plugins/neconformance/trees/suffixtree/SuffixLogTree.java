/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClassifier
 *  org.deckfour.xes.info.impl.XLogInfoImpl
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 */
package org.processmining.plugins.neconformance.trees.suffixtree;

import java.util.List;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.info.impl.XLogInfoImpl;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.plugins.neconformance.trees.LogTree;
import org.processmining.plugins.neconformance.trees.suffixtree.SuffixTree;
import org.processmining.plugins.neconformance.trees.suffixtree.SuffixTreeNode;

public class SuffixLogTree
implements LogTree {
    private XLog log;
    private XEventClassifier classifier;
    private int windowSize;
    private SuffixTree suffixTree;
    private int stateCounter;
    private static final String END_TRANSITION = "###ENDER###";

    public SuffixLogTree(XLog log) {
        this(log, XLogInfoImpl.STANDARD_CLASSIFIER, -1);
    }

    public SuffixLogTree(XLog log, XEventClassifier classifier) {
        this(log, classifier, -1);
    }

    public SuffixLogTree(XLog log, XEventClassifier classifier, int windowSize) {
        this.log = log;
        this.classifier = classifier;
        this.windowSize = windowSize;
        this.constructSuffixtree();
    }

    private void constructSuffixtree() {
        this.suffixTree = new SuffixTree();
        this.stateCounter = 0;
        int t = 0;
        while (t < this.log.size()) {
            XTrace trace = (XTrace)this.log.get(t);
            this.addTraceToSuffixTree(trace);
            ++t;
        }
    }

    public void addTraceToSuffixTree(XTrace trace) {
        int startIndex = 0;
        while (startIndex < trace.size()) {
            int endIndex;
            int n = endIndex = this.windowSize <= 0 ? 0 : startIndex - this.windowSize;
            if (endIndex < 0) {
                endIndex = 0;
            }
            SuffixTreeNode currentNode = this.suffixTree.getRootNode();
            int p = startIndex;
            while (p >= endIndex) {
                String eventClassP = this.classifier.getClassIdentity((XEvent)trace.get(p));
                SuffixTreeNode nextNode = this.suffixTree.getNodeOut(currentNode, eventClassP);
                if (nextNode == null) {
                    nextNode = this.suffixTree.addNode(currentNode, this.stateCounter++, eventClassP);
                }
                currentNode = nextNode;
                --p;
            }
            this.suffixTree.addNode(currentNode, this.stateCounter++, END_TRANSITION);
            ++startIndex;
        }
    }

    @Override
    public int getLongestMatchingWindowSize(List<String> window, String entryClass) {
        SuffixTreeNode currentNode = this.suffixTree.getNodeOut(this.suffixTree.getRootNode(), entryClass);
        if (currentNode == null) {
            System.err.println("Suffix tree could not enter entry class: " + entryClass + ", returning 0");
            return 0;
        }
        int windowPos = window.size() - 1;
        while (windowPos >= 0) {
            SuffixTreeNode nextNode = this.suffixTree.getNodeOut(currentNode, window.get(windowPos));
            if (nextNode == null) break;
            currentNode = nextNode;
            if (windowPos == 0) {
                return window.size();
            }
            --windowPos;
        }
        return window.size() - windowPos - 1;
    }

    @Override
    public int getShortestMatchingWindowSize(List<String> window, String entryClass) {
        SuffixTreeNode currentNode = this.suffixTree.getNodeOut(this.suffixTree.getRootNode(), entryClass);
        if (currentNode == null) {
            System.err.println("Suffix tree could not enter entry class: " + entryClass + ", returning 0");
            return 0;
        }
        int windowPos = window.size() - 1;
        while (windowPos >= 0) {
            if (this.suffixTree.nrNodesOut(currentNode) != 1) {
                return window.size() - windowPos - 1;
            }
            SuffixTreeNode nextNode = this.suffixTree.getNodeOut(currentNode, window.get(windowPos));
            if (nextNode == null) break;
            currentNode = nextNode;
            if (windowPos == 0) {
                return window.size();
            }
            --windowPos;
        }
        return window.size() - windowPos - 1;
    }

    public SuffixTree getSuffixTree() {
        return this.suffixTree;
    }

    public void setSuffixTree(SuffixTree suffixTree) {
        this.suffixTree = suffixTree;
    }
}

