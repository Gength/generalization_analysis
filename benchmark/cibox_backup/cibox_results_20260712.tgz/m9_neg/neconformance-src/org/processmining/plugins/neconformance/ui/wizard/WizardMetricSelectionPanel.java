/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.plugins.kutoolbox.ui.TwoColumnParameterPanel
 *  org.processmining.plugins.kutoolbox.ui.UIAttributeConfigurator
 */
package org.processmining.plugins.neconformance.ui.wizard;

import java.util.HashMap;
import java.util.Map;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import org.processmining.plugins.kutoolbox.ui.TwoColumnParameterPanel;
import org.processmining.plugins.kutoolbox.ui.UIAttributeConfigurator;

public class WizardMetricSelectionPanel
extends TwoColumnParameterPanel
implements UIAttributeConfigurator {
    private static final long serialVersionUID = -5233833365930723360L;
    private String metric;
    private JRadioButton radioRecall;
    private JRadioButton radioPrecision;
    private JRadioButton radioGeneralization;

    public WizardMetricSelectionPanel() {
        super(5);
        this.init();
    }

    protected void init() {
        this.resetSettings();
        this.addDoubleLabel("Select metric", 1);
        this.radioRecall = this.addRadiobutton("Behavioral Recall", this.metric.equals("recall"), 2, false);
        this.radioPrecision = this.addRadiobutton("Behavioral Precision", this.metric.equals("precision"), 3, false);
        this.radioGeneralization = this.addRadiobutton("Behavioral Generalization", this.metric.equals("generalization"), 4, false);
        ButtonGroup group = new ButtonGroup();
        group.add(this.radioRecall);
        group.add(this.radioPrecision);
        group.add(this.radioGeneralization);
    }

    public String getTitle() {
        return "Select a Metric";
    }

    public void resetSettings() {
        this.metric = "recall";
    }

    public void setSettings(Map<String, Object> settings) {
        this.metric = settings.get("metric").toString();
        if (this.metric.equals("recall")) {
            this.radioRecall.setSelected(true);
        }
        if (this.metric.equals("precision")) {
            this.radioPrecision.setSelected(true);
        }
        if (this.metric.equals("generalization")) {
            this.radioGeneralization.setSelected(true);
        }
    }

    public Map<String, Object> getSettings() {
        if (this.radioRecall.isSelected()) {
            this.metric = "recall";
        }
        if (this.radioPrecision.isSelected()) {
            this.metric = "precision";
        }
        if (this.radioGeneralization.isSelected()) {
            this.metric = "generalization";
        }
        HashMap<String, Object> settings = new HashMap<String, Object>();
        settings.put("metric", this.metric);
        return settings;
    }

    protected void updateFields() {
    }
}

