/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.model.XTrace
 */
package org.processmining.plugins.neconformance.negativeevents;

import java.util.Set;
import org.deckfour.xes.model.XTrace;
import org.processmining.plugins.neconformance.types.WeightedEventClass;

public interface NegativeEventInducer {
    public Set<WeightedEventClass> getNegativeEvents(XTrace var1, int var2);

    public Set<WeightedEventClass> getGeneralizedEvents(XTrace var1, int var2);
}

