/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 */
package org.processmining.plugins.neconformance.models.impl;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.utils.PetrinetReplayUtils;

public class RecoveringPetrinetReplayModel
extends PetrinetReplayModel {
    protected boolean greedyInvisibles;

    public RecoveringPetrinetReplayModel(Petrinet net, Marking initialMarking, PetrinetLogMapper mapping) {
        super(net, initialMarking, mapping);
    }

    public RecoveringPetrinetReplayModel(RecoveringPetrinetReplayModel toClone) {
        this(toClone.getPetrinet(), (Marking)toClone.getInitialState(), toClone.getMapping());
        this.setGreedyInvisibles(toClone.isGreedyInvisibles());
    }

    @Override
    public void reset() {
        super.reset();
        this.greedyInvisibles = false;
    }

    @Override
    public void replay(List<XEventClass> trace) {
        this.reset();
        int currentSequencePosition = 0;
        while (currentSequencePosition < trace.size()) {
            XEventClass currentClass = trace.get(currentSequencePosition);
            XEventClass nextClass = currentSequencePosition < trace.size() - 1 ? trace.get(currentSequencePosition + 1) : null;
            Set<Object> MT = new HashSet();
            Set<Object> ET = new HashSet();
            Set<Object> VT = new HashSet();
            Set<Object> IT = new HashSet();
            Set<Object> CET = new HashSet();
            Set<Object> NET = new HashSet();
            MT = PetrinetReplayUtils.getMappedTransitions(this.mapping, currentClass);
            ET = PetrinetReplayUtils.getEnabledTransitions(this.net, this.currentMarking);
            VT = PetrinetReplayUtils.getVisibleTransitions(this.net, this.mapping);
            IT = PetrinetReplayUtils.getInvisibleTransitions(this.net, this.mapping);
            CET = this.filterOnNextTaskEnabler(this.net.getTransitions(), currentClass);
            NET = this.filterOnNextTaskEnabler(this.net.getTransitions(), nextClass);
            ProcessReplayModel.ReplayMove move = null;
            Transition t = null;
            XEventClass c = null;
            boolean f = false;
            Transition r = this.getRandomTransitionFromIntersect(MT, ET, NET);
            if (r != null) {
                t = r;
                c = currentClass;
                move = ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS;
            } else {
                r = this.getRandomTransitionFromIntersect(MT, ET);
                if (r != null) {
                    t = r;
                    c = currentClass;
                    move = ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS;
                } else {
                    r = this.getRandomTransitionFromIntersect(IT, ET, CET);
                    if (r != null) {
                        t = r;
                        c = null;
                        move = ProcessReplayModel.ReplayMove.MODELONLY_UNOBSERVABLE;
                    } else {
                        r = this.getRandomTransitionFromIntersect(MT, NET);
                        if (r != null) {
                            t = r;
                            c = currentClass;
                            move = ProcessReplayModel.ReplayMove.BOTH_FORCED;
                        } else {
                            r = this.getRandomTransitionFromIntersect(MT);
                            if (r != null) {
                                t = r;
                                c = currentClass;
                                move = ProcessReplayModel.ReplayMove.BOTH_FORCED;
                            } else {
                                r = this.getRandomTransitionFromIntersect(VT, ET, CET);
                                if (r != null) {
                                    t = r;
                                    c = null;
                                    move = ProcessReplayModel.ReplayMove.MODELONLY_SKIPPED;
                                } else {
                                    r = this.getRandomTransitionFromIntersect(IT, CET);
                                    if (r != null) {
                                        t = r;
                                        c = null;
                                        move = ProcessReplayModel.ReplayMove.BOTH_FORCED;
                                    } else {
                                        r = this.getRandomTransitionFromIntersect(VT, CET);
                                        if (r != null) {
                                            t = r;
                                            c = null;
                                            move = ProcessReplayModel.ReplayMove.MODELONLY_SKIPPED;
                                        } else {
                                            t = null;
                                            c = currentClass;
                                            move = ProcessReplayModel.ReplayMove.LOGONLY_INSERTED;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Marking m = this.currentMarking;
            if (t != null) {
                m = PetrinetReplayUtils.getMarkingAfterFire(this.net, m, t);
            }
            if (c != null) {
                ++currentSequencePosition;
            }
            this.addReplayStep(move, t, c, m);
            this.transitionIsForced.add(f);
            this.currentMarking = m;
        }
    }

    @SafeVarargs
    private final Transition getRandomTransitionFromIntersect(Set<Transition> ... choices) {
        Set<Transition> total = choices[0];
        Set<Transition>[] setArray = choices;
        int n = choices.length;
        int n2 = 0;
        while (n2 < n) {
            Set<Transition> c = setArray[n2];
            total.retainAll(c);
            ++n2;
        }
        if (total.size() == 0) {
            return null;
        }
        return this.getRandomTransition(total);
    }

    private Transition getRandomTransition(Set<Transition> choices) {
        int index = this.generator.nextInt(choices.size());
        return (Transition)choices.toArray()[index];
    }

    private Set<Transition> filterOnNextTaskEnabler(Collection<Transition> collection, XEventClass eclass) {
        HashSet<Transition> filtered = new HashSet<Transition>();
        if (eclass == null) {
            return filtered;
        }
        for (Transition t : collection) {
            Marking nextState = PetrinetReplayUtils.getMarkingAfterFire(this.net, this.currentMarking, t);
            Set<Transition> nextTaskEnabledTransitions = PetrinetReplayUtils.getEnabledMappedTransitions(this.net, nextState, this.mapping, eclass);
            if (nextTaskEnabledTransitions != null && nextTaskEnabledTransitions.size() <= 0) continue;
            filtered.add(t);
        }
        return filtered;
    }

    public boolean isGreedyInvisibles() {
        return this.greedyInvisibles;
    }

    public void setGreedyInvisibles(boolean greedyInvisibles) {
        this.greedyInvisibles = greedyInvisibles;
    }
}

