/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.trees.suffixtree;

import org.processmining.plugins.neconformance.trees.suffixtree.SuffixTreeNode;

public class SuffixTreeEdge {
    private SuffixTreeNode from;
    private SuffixTreeNode to;
    private String transitionName;

    public SuffixTreeEdge(SuffixTreeNode from, SuffixTreeNode to, String transitionName) {
        this.from = from;
        this.to = to;
        this.transitionName = transitionName;
    }

    public SuffixTreeNode getFrom() {
        return this.from;
    }

    public SuffixTreeNode getTo() {
        return this.to;
    }

    public String getTransitionName() {
        return this.transitionName;
    }

    public int hashCode() {
        int prime = 31;
        int result = 1;
        result = 31 * result + (this.from == null ? 0 : this.from.hashCode());
        result = 31 * result + (this.to == null ? 0 : this.to.hashCode());
        result = 31 * result + (this.transitionName == null ? 0 : this.transitionName.hashCode());
        return result;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        SuffixTreeEdge other = (SuffixTreeEdge)obj;
        if (this.from == null ? other.from != null : !this.from.equals(other.from)) {
            return false;
        }
        if (this.to == null ? other.to != null : !this.to.equals(other.to)) {
            return false;
        }
        return !(this.transitionName == null ? other.transitionName != null : !this.transitionName.equals(other.transitionName));
    }

    public String toString() {
        return "--(" + this.transitionName + ")->";
    }
}

