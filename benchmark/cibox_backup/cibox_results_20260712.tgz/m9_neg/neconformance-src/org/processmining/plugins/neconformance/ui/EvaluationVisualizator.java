/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.model.XLog
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 *  org.processmining.plugins.kutoolbox.utils.PetrinetUtils
 */
package org.processmining.plugins.neconformance.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.model.XLog;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.kutoolbox.utils.PetrinetUtils;
import org.processmining.plugins.neconformance.metrics.impl.BehavioralRecallMetric;
import org.processmining.plugins.neconformance.metrics.impl.BehavioralWeightedGeneralizationMetric;
import org.processmining.plugins.neconformance.metrics.impl.BehavioralWeightedPrecisionMetric;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;
import org.processmining.plugins.neconformance.negativeevents.impl.LogTreeWeightedNegativeEventInducer;
import org.processmining.plugins.neconformance.ui.AlignmentPane;
import org.processmining.plugins.neconformance.ui.InformationPane;
import org.processmining.plugins.neconformance.ui.PetrinetPane;
import org.processmining.plugins.neconformance.ui.TraceSelectorPane;

public class EvaluationVisualizator
extends JPanel {
    private static final long serialVersionUID = -4828826958007119206L;
    private List<ProcessReplayModel<Transition, XEventClass, Marking>> replayModels;
    private AbstractNegativeEventInducer inducer;
    private XLog log;
    private PetrinetLogMapper mapper;
    private InformationPane infoPane;
    private AlignmentPane alignPane;
    private TraceSelectorPane tracePane;
    private PetrinetPane petriPane;
    private Petrinet net;
    private Marking marking;

    public EvaluationVisualizator(List<ProcessReplayModel<Transition, XEventClass, Marking>> replayModels, LogTreeWeightedNegativeEventInducer inducer, XLog log, Petrinet net, Marking marking, PetrinetLogMapper mapper) {
        this(replayModels, inducer, log, net, marking, mapper, false);
    }

    public EvaluationVisualizator(List<ProcessReplayModel<Transition, XEventClass, Marking>> replayModels, AbstractNegativeEventInducer inducer, XLog log, Petrinet net, Marking marking, PetrinetLogMapper mapper, boolean surpressMetricCalculation) {
        this.replayModels = replayModels;
        this.inducer = inducer;
        this.log = log;
        this.net = net;
        this.marking = marking;
        this.mapper = mapper;
        this.infoPane = new InformationPane(this);
        this.alignPane = new AlignmentPane(this);
        this.tracePane = new TraceSelectorPane(this);
        this.petriPane = new PetrinetPane(this);
        this.setLayout(new BorderLayout());
        this.add((Component)this.alignPane, "South");
        JSplitPane split = new JSplitPane(1, this.tracePane, this.petriPane);
        JSplitPane splitMain = new JSplitPane(1, split, this.infoPane);
        this.add((Component)splitMain, "Center");
        if (!surpressMetricCalculation) {
            PetrinetReplayModel replayModel = new PetrinetReplayModel(net, PetrinetUtils.getInitialMarking((Petrinet)this.net, (Marking)this.marking), mapper);
            BehavioralRecallMetric br = new BehavioralRecallMetric(replayModel, inducer, log, true, true);
            BehavioralWeightedPrecisionMetric bp = new BehavioralWeightedPrecisionMetric(replayModel, inducer, log, true, true);
            BehavioralWeightedGeneralizationMetric bg = new BehavioralWeightedGeneralizationMetric(replayModel, inducer, log, true, true);
            String text = "";
            text = String.valueOf(text) + "Recall: " + br.getValue() + "\n";
            text = String.valueOf(text) + "Precision: " + bp.getValue() + "\n";
            text = String.valueOf(text) + "Generalization: " + bg.getValue() + "\n";
            this.infoPane.setText(text);
        } else {
            this.infoPane.setText("Metric calculation is surpressed");
        }
    }

    public List<ProcessReplayModel<Transition, XEventClass, Marking>> getReplayModels() {
        return this.replayModels;
    }

    public AbstractNegativeEventInducer getInducer() {
        return this.inducer;
    }

    public XLog getLog() {
        return this.log;
    }

    public Petrinet getNet() {
        return this.net;
    }

    public PetrinetLogMapper getMapper() {
        return this.mapper;
    }

    public void notifyTraceSelection(int selectedIndex) {
        if (selectedIndex <= 0) {
            this.petriPane.notifyGlobalView();
        } else {
            this.petriPane.notifyTraceSelection(selectedIndex - 1);
            this.alignPane.notifyTraceSelection(selectedIndex - 1);
        }
    }

    public void notifyReplayStepSelection(int selectedTraceIndex, int selectedReplayIndex) {
        if (selectedReplayIndex < 0) {
            return;
        }
        this.petriPane.notifyReplayStepSelection(selectedTraceIndex, selectedReplayIndex);
    }
}

