/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.models.graphbased.directed.AbstractDirectedGraph
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetEdge
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetNode
 *  org.processmining.models.graphbased.directed.petrinet.elements.ExpandableSubNet
 *  org.processmining.models.graphbased.directed.petrinet.elements.Place
 *  org.processmining.models.shapes.Decorated
 */
package org.processmining.plugins.neconformance.ui.graphics;

import java.awt.Dimension;
import java.awt.Graphics2D;
import org.processmining.models.graphbased.directed.AbstractDirectedGraph;
import org.processmining.models.graphbased.directed.petrinet.PetrinetEdge;
import org.processmining.models.graphbased.directed.petrinet.PetrinetNode;
import org.processmining.models.graphbased.directed.petrinet.elements.ExpandableSubNet;
import org.processmining.models.graphbased.directed.petrinet.elements.Place;
import org.processmining.models.shapes.Decorated;
import org.processmining.plugins.neconformance.ui.graphics.IPlacePDecorator;
import org.processmining.plugins.neconformance.ui.graphics.PetrinetGraphP;

public class PlaceP
extends Place
implements Decorated {
    protected IPlacePDecorator decorator;

    public PlaceP(String label, AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>> net) {
        super(label, net);
    }

    public PlaceP(String label, AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>> net, Dimension dimension) {
        super(label, net);
        this.getAttributeMap().put("size", (Object)dimension);
    }

    public PlaceP(String label, PetrinetGraphP net, ExpandableSubNet parent) {
        super(label, (AbstractDirectedGraph)net, parent);
    }

    public PlaceP(String label, PetrinetGraphP net, ExpandableSubNet parent, Dimension dimension) {
        super(label, (AbstractDirectedGraph)net, parent);
        this.getAttributeMap().put("size", (Object)dimension);
    }

    public void decorate(Graphics2D g2d, double x, double y, double width, double height) {
        if (this.decorator != null) {
            this.decorator.decorate(g2d, x, y, width, height);
        }
    }
}

