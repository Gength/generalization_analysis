/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.trees.ukkonen;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.processmining.plugins.neconformance.trees.ukkonen.SequenceTerminal;

public class Sequence<I, S extends Iterable<I>>
implements Iterable<Object> {
    private List<Object> masterSequence = new ArrayList<Object>();

    Sequence() {
    }

    Sequence(S sequence) {
        for (Object item : sequence) {
            this.masterSequence.add(item);
        }
        SequenceTerminal<S> sequenceTerminal = new SequenceTerminal<S>(sequence);
        this.masterSequence.add(sequenceTerminal);
    }

    Object getItem(int index) {
        return this.masterSequence.get(index);
    }

    void add(S sequence) {
        for (Object item : sequence) {
            this.masterSequence.add(item);
        }
        SequenceTerminal<S> terminal = new SequenceTerminal<S>(sequence);
        this.masterSequence.add(terminal);
    }

    @Override
    public Iterator<Object> iterator() {
        return new Iterator<Object>(){
            int currentPosition = 0;

            @Override
            public boolean hasNext() {
                return Sequence.this.masterSequence.size() > this.currentPosition;
            }

            @Override
            public Object next() {
                if (this.currentPosition <= Sequence.this.masterSequence.size()) {
                    return Sequence.this.masterSequence.get(this.currentPosition++);
                }
                return null;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException("Remove is not supported.");
            }
        };
    }

    int getLength() {
        return this.masterSequence.size();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("Sequence = [");
        for (Object i : this.masterSequence) {
            sb.append(i).append(", ");
        }
        sb.append("]");
        return sb.toString();
    }
}

