/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.model.XLog
 */
package org.processmining.plugins.neconformance.metrics.impl;

import org.deckfour.xes.model.XLog;
import org.processmining.plugins.neconformance.metrics.impl.AbstractBehavioralPetrinetMetric;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;

public class BehavioralWeightedGeneralizationMetric
extends AbstractBehavioralPetrinetMetric {
    public BehavioralWeightedGeneralizationMetric(PetrinetReplayModel replayModel, AbstractNegativeEventInducer inducer, XLog log, boolean checkUnmapped, boolean useMultiTreadedCalculation) {
        super(replayModel, inducer, log, false, true, false, false, useMultiTreadedCalculation);
    }

    @Override
    protected double getCalculatedValue() {
        if (this.allowedGeneralizations == 0.0 && this.disallowedGeneralizations == 0.0) {
            return 1.0;
        }
        return this.allowedGeneralizations / (this.allowedGeneralizations + this.disallowedGeneralizations);
    }
}

