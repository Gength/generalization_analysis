/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;

public abstract class AbstractProcessReplayModel<M, L, S>
implements ProcessReplayModel<M, L, S> {
    protected List<ProcessReplayModel.ReplayMove> replayMoveSequence = new ArrayList<ProcessReplayModel.ReplayMove>();
    protected Set<M> modelElements = new HashSet<M>();
    protected Set<L> logElements = new HashSet<L>();
    protected List<M> modelElementSequence = new ArrayList<M>();
    protected List<L> traceElementSequence = new ArrayList<L>();
    protected List<S> stateSequence = new ArrayList<S>();
    protected S initialState;

    protected AbstractProcessReplayModel(Collection<M> modelElements, Collection<L> logElements, S initialState) {
        this.modelElements = new HashSet<M>(modelElements);
        this.logElements = new HashSet<L>(logElements);
        this.initialState = initialState;
    }

    protected AbstractProcessReplayModel(AbstractProcessReplayModel<M, L, S> toClone) {
        this(toClone.getModelElements(), toClone.getLogElements(), toClone.getInitialState());
    }

    @Override
    public int size() {
        return this.replayMoveSequence.size();
    }

    @Override
    public ProcessReplayModel.ReplayMove getReplayMove(int index) {
        return this.replayMoveSequence.get(index);
    }

    @Override
    public M getModelElement(int index) {
        return this.modelElementSequence.get(index);
    }

    @Override
    public L getTraceElement(int index) {
        return this.traceElementSequence.get(index);
    }

    @Override
    public S getModelState(int index) {
        if (index == -1) {
            return this.getInitialState();
        }
        return this.stateSequence.get(index);
    }

    @Override
    public S getInitialState() {
        return this.initialState;
    }

    public Set<M> getModelElements() {
        return this.modelElements;
    }

    public Set<L> getLogElements() {
        return this.logElements;
    }

    @Override
    public void addReplayStep(ProcessReplayModel.ReplayMove move, M modelElement, L traceElement, S stateAfterStep) {
        this.replayMoveSequence.add(move);
        this.modelElementSequence.add(modelElement);
        this.traceElementSequence.add(traceElement);
        this.stateSequence.add(stateAfterStep);
    }

    @Override
    public void reset() {
        this.replayMoveSequence = new ArrayList<ProcessReplayModel.ReplayMove>();
        this.modelElementSequence = new ArrayList<M>();
        this.traceElementSequence = new ArrayList<L>();
        this.stateSequence = new ArrayList<S>();
    }

    @Override
    public Set<M> getExecutableModelElements(S state) {
        HashSet<M> elements = new HashSet<M>();
        for (M element : this.getModelElements()) {
            if (!this.isExecutableModelElement(element, state)) continue;
            elements.add(element);
        }
        return elements;
    }

    @Override
    public Set<L> getExecutableLogElements(S state) {
        HashSet<L> elements = new HashSet<L>();
        for (L element : this.getLogElements()) {
            if (!this.isExecutableLogElement(element, state)) continue;
            elements.add(element);
        }
        return elements;
    }

    @Override
    public abstract boolean isExecutableModelElement(M var1, S var2);

    @Override
    public abstract boolean isExecutableLogElement(L var1, S var2);

    @Override
    public abstract void replay(List<L> var1);
}

