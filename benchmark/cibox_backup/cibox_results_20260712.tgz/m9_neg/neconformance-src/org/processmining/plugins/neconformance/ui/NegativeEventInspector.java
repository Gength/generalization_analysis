/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.classification.XEventClassifier
 *  org.deckfour.xes.extension.std.XConceptExtension
 *  org.deckfour.xes.extension.std.XLifecycleExtension
 *  org.deckfour.xes.factory.XFactory
 *  org.deckfour.xes.factory.XFactoryRegistry
 *  org.deckfour.xes.info.impl.XLogInfoImpl
 *  org.deckfour.xes.model.XAttributable
 *  org.deckfour.xes.model.XAttributeMap
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.contexts.uitopia.UIPluginContext
 *  org.processmining.framework.plugin.PluginContext
 *  org.processmining.plugins.kutoolbox.groupedlog.GroupedXLog
 */
package org.processmining.plugins.neconformance.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.extension.std.XConceptExtension;
import org.deckfour.xes.extension.std.XLifecycleExtension;
import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.factory.XFactoryRegistry;
import org.deckfour.xes.info.impl.XLogInfoImpl;
import org.deckfour.xes.model.XAttributable;
import org.deckfour.xes.model.XAttributeMap;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.contexts.uitopia.UIPluginContext;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.plugins.kutoolbox.groupedlog.GroupedXLog;
import org.processmining.plugins.neconformance.bags.naieve.NaieveLogBag;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;
import org.processmining.plugins.neconformance.negativeevents.NegativeEventInducer;
import org.processmining.plugins.neconformance.negativeevents.impl.LogBagWeightedNegativeEventInducer;
import org.processmining.plugins.neconformance.negativeevents.impl.LogTreeWeightedNegativeEventInducer;
import org.processmining.plugins.neconformance.trees.ukkonen.UkkonenLogTree;
import org.processmining.plugins.neconformance.types.WeightedEventClass;

public class NegativeEventInspector
extends JPanel {
    private static final long serialVersionUID = -1596900072533174028L;
    private XLog log;
    private GroupedXLog glog;
    private NegativeEventInducer inducer;
    private JPanel distributionPanel;
    private double[] bins;
    private Map<Double, Integer> negativeWeights;
    private Map<Double, Integer> generalizedWeights;
    private UIPluginContext context;

    public NegativeEventInspector(XLog log, UIPluginContext context) {
        this.log = log;
        this.glog = new GroupedXLog(log);
        this.context = context;
        this.bins = new double[]{0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0};
        this.resetBins();
        this.createInducer(false);
        this.init();
    }

    private void createInducer(boolean useBags) {
        XEventClasses eventClasses = XEventClasses.deriveEventClasses((XEventClassifier)XLogInfoImpl.STANDARD_CLASSIFIER, (XLog)this.log);
        if (!useBags) {
            UkkonenLogTree logTree = new UkkonenLogTree(this.glog.getGroupedLog());
            this.inducer = new LogTreeWeightedNegativeEventInducer(eventClasses, AbstractNegativeEventInducer.deriveStartingClasses(eventClasses, this.log), logTree);
            ((LogTreeWeightedNegativeEventInducer)this.inducer).setReturnZeroEvents(true);
        } else {
            NaieveLogBag logBag = new NaieveLogBag(this.glog.getGroupedLog());
            this.inducer = new LogBagWeightedNegativeEventInducer(eventClasses, AbstractNegativeEventInducer.deriveStartingClasses(eventClasses, this.log), logBag);
            ((LogBagWeightedNegativeEventInducer)this.inducer).setReturnZeroEvents(true);
        }
    }

    private void resetBins() {
        this.negativeWeights = new HashMap<Double, Integer>();
        this.generalizedWeights = new HashMap<Double, Integer>();
        int i = 1;
        while (i < this.bins.length) {
            this.negativeWeights.put(this.bins[i], 0);
            this.generalizedWeights.put(this.bins[i], 0);
            ++i;
        }
    }

    private void incrementBin(double value, Map<Double, Integer> target) {
        int i = 1;
        while (i < this.bins.length) {
            if (value <= this.bins[i]) {
                target.put(this.bins[i], target.get(this.bins[i]) + 1);
                return;
            }
            ++i;
        }
    }

    private void init() {
        this.setLayout(new BorderLayout());
        JPanel topRow = new JPanel();
        topRow.add(new JLabel("Log: " + XConceptExtension.instance().extractName((XAttributable)this.log)));
        this.add((Component)topRow, "North");
        JPanel rightPane = new JPanel();
        this.distributionPanel = new JPanel(){
            private static final long serialVersionUID = 3042808819703334081L;

            private int valueToPos(double min, double max, double value, double targetSize) {
                double normalizedValue = (value - min) / (max - min);
                double widthPos = targetSize * normalizedValue;
                return (int)widthPos;
            }

            @Override
            public void paint(Graphics g) {
                int v;
                if (g == null) {
                    return;
                }
                super.paint(g);
                int[] binPositions = new int[NegativeEventInspector.this.bins.length];
                int i = 0;
                while (i < NegativeEventInspector.this.bins.length) {
                    binPositions[i] = this.valueToPos(NegativeEventInspector.this.bins[0], NegativeEventInspector.this.bins[NegativeEventInspector.this.bins.length - 1], NegativeEventInspector.this.bins[i], this.getSize().width);
                    ++i;
                }
                int max = 0;
                Iterator iterator = NegativeEventInspector.this.negativeWeights.values().iterator();
                while (iterator.hasNext()) {
                    v = (Integer)iterator.next();
                    if (v <= max) continue;
                    max = v;
                }
                iterator = NegativeEventInspector.this.generalizedWeights.values().iterator();
                while (iterator.hasNext()) {
                    v = (Integer)iterator.next();
                    if (v <= max) continue;
                    max = v;
                }
                g.setColor(Color.black);
                g.drawLine(0, this.getSize().height - 50, this.getSize().width, this.getSize().height - 50);
                int i2 = 0;
                while (i2 < NegativeEventInspector.this.bins.length) {
                    g.drawString(" ^- " + NegativeEventInspector.this.bins[i2], binPositions[i2], this.getSize().height - 25);
                    ++i2;
                }
                i2 = 1;
                while (i2 < NegativeEventInspector.this.bins.length) {
                    int negnr = (Integer)NegativeEventInspector.this.negativeWeights.get(NegativeEventInspector.this.bins[i2]);
                    int gennr = (Integer)NegativeEventInspector.this.generalizedWeights.get(NegativeEventInspector.this.bins[i2]);
                    int width = (int)Math.floor(((double)binPositions[i2] - (double)binPositions[i2 - 1]) / 2.0);
                    int height1 = this.valueToPos(0.0, max, negnr, this.getSize().height - 100);
                    int height2 = this.valueToPos(0.0, max, gennr, this.getSize().height - 100);
                    g.setColor(Color.red);
                    g.fillRect(binPositions[i2 - 1], this.getSize().height - 50 - height1, width, height1);
                    g.setColor(Color.blue);
                    g.fillRect(binPositions[i2 - 1] + width, this.getSize().height - 50 - height2, width, height2);
                    g.setColor(Color.black);
                    g.drawString(" v- " + negnr, binPositions[i2 - 1], this.getSize().height - 75 - height1);
                    g.drawString(" v- " + gennr, binPositions[i2 - 1] + width, this.getSize().height - 75 - height2);
                    ++i2;
                }
            }
        };
        rightPane.setLayout(new BoxLayout(rightPane, 3));
        int negwin = -1;
        int genwin = -1;
        boolean useBag = false;
        boolean useWeighted = false;
        boolean useBothRat = false;
        boolean useCut = false;
        if (this.inducer instanceof LogTreeWeightedNegativeEventInducer) {
            negwin = ((LogTreeWeightedNegativeEventInducer)this.inducer).getNegWindowSize();
            genwin = ((LogTreeWeightedNegativeEventInducer)this.inducer).getGenWindowSize();
            useBag = false;
            useWeighted = ((LogTreeWeightedNegativeEventInducer)this.inducer).isUseWeighted();
            useBothRat = ((LogTreeWeightedNegativeEventInducer)this.inducer).isUseBothWindowRatios();
            useCut = ((LogTreeWeightedNegativeEventInducer)this.inducer).isUseWindowOccurrenceCut();
        }
        if (this.inducer instanceof LogBagWeightedNegativeEventInducer) {
            negwin = ((LogBagWeightedNegativeEventInducer)this.inducer).getNegWindowSize();
            genwin = ((LogBagWeightedNegativeEventInducer)this.inducer).getGenWindowSize();
            useBag = true;
            useWeighted = ((LogBagWeightedNegativeEventInducer)this.inducer).isUseWeighted();
            useBothRat = ((LogBagWeightedNegativeEventInducer)this.inducer).isUseBothWindowRatios();
            useCut = ((LogBagWeightedNegativeEventInducer)this.inducer).isUseWindowOccurrenceCut();
        }
        final JCheckBox checkInducetype = new JCheckBox("Select to use bag prefix instead of sequence", useBag);
        checkInducetype.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                NegativeEventInspector.this.createInducer(checkInducetype.isSelected());
                NegativeEventInspector.this.recalculate();
            }
        });
        final JCheckBox checkWeighted = new JCheckBox("Use weighted metrics", useWeighted);
        checkWeighted.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (NegativeEventInspector.this.inducer instanceof LogTreeWeightedNegativeEventInducer) {
                    ((LogTreeWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setUseWeighted(checkWeighted.isSelected());
                }
                if (NegativeEventInspector.this.inducer instanceof LogBagWeightedNegativeEventInducer) {
                    ((LogBagWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setUseWeighted(checkWeighted.isSelected());
                }
                NegativeEventInspector.this.recalculate();
            }
        });
        final JCheckBox checkBothratios = new JCheckBox("Use longest and shortest matching windows", useBothRat);
        checkBothratios.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (NegativeEventInspector.this.inducer instanceof LogTreeWeightedNegativeEventInducer) {
                    ((LogTreeWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setUseBothWindowRatios(checkBothratios.isSelected());
                }
                if (NegativeEventInspector.this.inducer instanceof LogBagWeightedNegativeEventInducer) {
                    ((LogBagWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setUseBothWindowRatios(checkBothratios.isSelected());
                }
                NegativeEventInspector.this.recalculate();
            }
        });
        final JCheckBox checkStopoccurrence = new JCheckBox("Cut windows at next event occurrence", useCut);
        checkStopoccurrence.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                if (NegativeEventInspector.this.inducer instanceof LogTreeWeightedNegativeEventInducer) {
                    ((LogTreeWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setUseWindowOccurrenceCut(checkStopoccurrence.isSelected());
                }
                if (NegativeEventInspector.this.inducer instanceof LogBagWeightedNegativeEventInducer) {
                    ((LogBagWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setUseWindowOccurrenceCut(checkStopoccurrence.isSelected());
                }
                NegativeEventInspector.this.recalculate();
            }
        });
        final JSlider negSlider = new JSlider(-1, 10, negwin);
        negSlider.addChangeListener(new ChangeListener(){

            @Override
            public void stateChanged(ChangeEvent arg0) {
                if (negSlider.getValue() == 0) {
                    return;
                }
                if (NegativeEventInspector.this.inducer instanceof LogTreeWeightedNegativeEventInducer) {
                    ((LogTreeWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setNegWindowSize(negSlider.getValue());
                }
                if (NegativeEventInspector.this.inducer instanceof LogBagWeightedNegativeEventInducer) {
                    ((LogBagWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setNegWindowSize(negSlider.getValue());
                }
                NegativeEventInspector.this.recalculate();
            }
        });
        final JSlider genSlider = new JSlider(-1, 10, genwin);
        genSlider.addChangeListener(new ChangeListener(){

            @Override
            public void stateChanged(ChangeEvent arg0) {
                if (genSlider.getValue() == 0) {
                    return;
                }
                if (NegativeEventInspector.this.inducer instanceof LogTreeWeightedNegativeEventInducer) {
                    ((LogTreeWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setGenWindowSize(genSlider.getValue());
                }
                if (NegativeEventInspector.this.inducer instanceof LogBagWeightedNegativeEventInducer) {
                    ((LogBagWeightedNegativeEventInducer)NegativeEventInspector.this.inducer).setGenWindowSize(genSlider.getValue());
                }
                NegativeEventInspector.this.recalculate();
            }
        });
        final JButton logExporter = new JButton("Export Log");
        logExporter.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent arg0) {
                logExporter.setEnabled(false);
                logExporter.setText("Exporting...");
                XFactory xFactory = (XFactory)XFactoryRegistry.instance().currentDefault();
                XLog newlog = xFactory.createLog((XAttributeMap)NegativeEventInspector.this.log.getAttributes().clone());
                for (XTrace trace : NegativeEventInspector.this.log) {
                    XTrace newtrace = xFactory.createTrace((XAttributeMap)trace.getAttributes().clone());
                    int position = 0;
                    while (position < trace.size()) {
                        XEvent ne;
                        Set<WeightedEventClass> negatives = NegativeEventInspector.this.inducer.getNegativeEvents(trace, position);
                        Set<WeightedEventClass> generalized = NegativeEventInspector.this.inducer.getGeneralizedEvents(trace, position);
                        for (WeightedEventClass we : negatives) {
                            ne = xFactory.createEvent();
                            XConceptExtension.instance().assignName((XAttributable)ne, we.eventClass.getId());
                            XLifecycleExtension.instance().assignTransition(ne, String.valueOf(XLifecycleExtension.instance().extractTransition((XEvent)trace.get(position))) + "-negative");
                            ne.getAttributes().put((Object)"weight", (Object)xFactory.createAttributeContinuous("weight", we.weight, null));
                            newtrace.add((Object)ne);
                        }
                        for (WeightedEventClass we : generalized) {
                            ne = xFactory.createEvent();
                            XConceptExtension.instance().assignName((XAttributable)ne, we.eventClass.getId());
                            XLifecycleExtension.instance().assignTransition(ne, String.valueOf(XLifecycleExtension.instance().extractTransition((XEvent)trace.get(position))) + "-generalized");
                            ne.getAttributes().put((Object)"weight", (Object)xFactory.createAttributeContinuous("weight", we.weight, null));
                            newtrace.add((Object)ne);
                        }
                        newtrace.add((Object)xFactory.createEvent((XAttributeMap)((XEvent)trace.get(position)).getAttributes().clone()));
                        ++position;
                    }
                    newlog.add((Object)newtrace);
                }
                logExporter.setEnabled(true);
                logExporter.setText("Export Log");
                NegativeEventInspector.this.context.getProvidedObjectManager().createProvidedObject("Exported Log with Negative Events", (Object)newlog, XLog.class, (PluginContext)NegativeEventInspector.this.context);
            }
        });
        rightPane.add(checkInducetype);
        rightPane.add(checkWeighted);
        rightPane.add(checkBothratios);
        rightPane.add(checkStopoccurrence);
        rightPane.add(negSlider);
        rightPane.add(genSlider);
        rightPane.add(logExporter);
        JSplitPane splitPane = new JSplitPane(1, this.distributionPanel, rightPane);
        this.add((Component)splitPane, "Center");
        this.recalculate();
    }

    public void recalculate() {
        this.resetBins();
        for (XTrace trace : this.log) {
            int position = 0;
            while (position < trace.size()) {
                Set<WeightedEventClass> negatives = this.inducer.getNegativeEvents(trace, position);
                Set<WeightedEventClass> generalized = this.inducer.getGeneralizedEvents(trace, position);
                for (WeightedEventClass we : negatives) {
                    this.incrementBin(we.weight, this.negativeWeights);
                }
                for (WeightedEventClass we : generalized) {
                    this.incrementBin(we.weight, this.generalizedWeights);
                }
                ++position;
            }
        }
        this.distributionPanel.revalidate();
        this.distributionPanel.repaint();
    }
}

