/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jgraph.layout.JGraphFacade
 *  com.jgraph.layout.JGraphLayout
 *  com.jgraph.layout.hierarchical.JGraphHierarchicalLayout
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.model.XTrace
 *  org.jgraph.JGraph
 *  org.processmining.framework.util.ui.scalableview.ScalableComponent
 *  org.processmining.models.connections.GraphLayoutConnection
 *  org.processmining.models.graphbased.ViewSpecificAttributeMap
 *  org.processmining.models.graphbased.directed.DirectedGraph
 *  org.processmining.models.graphbased.directed.DirectedGraphEdge
 *  org.processmining.models.graphbased.directed.DirectedGraphNode
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetEdge
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetGraph
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetNode
 *  org.processmining.models.graphbased.directed.petrinet.elements.Arc
 *  org.processmining.models.graphbased.directed.petrinet.elements.Place
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.jgraph.ProMGraphModel
 *  org.processmining.models.jgraph.ProMJGraph
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.visualizators.GraphViewPanel
 */
package org.processmining.plugins.neconformance.ui.simple;

import com.jgraph.layout.JGraphFacade;
import com.jgraph.layout.JGraphLayout;
import com.jgraph.layout.hierarchical.JGraphHierarchicalLayout;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.swing.JPanel;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.model.XTrace;
import org.jgraph.JGraph;
import org.processmining.framework.util.ui.scalableview.ScalableComponent;
import org.processmining.models.connections.GraphLayoutConnection;
import org.processmining.models.graphbased.ViewSpecificAttributeMap;
import org.processmining.models.graphbased.directed.DirectedGraph;
import org.processmining.models.graphbased.directed.DirectedGraphEdge;
import org.processmining.models.graphbased.directed.DirectedGraphNode;
import org.processmining.models.graphbased.directed.petrinet.PetrinetEdge;
import org.processmining.models.graphbased.directed.petrinet.PetrinetGraph;
import org.processmining.models.graphbased.directed.petrinet.PetrinetNode;
import org.processmining.models.graphbased.directed.petrinet.elements.Arc;
import org.processmining.models.graphbased.directed.petrinet.elements.Place;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.jgraph.ProMGraphModel;
import org.processmining.models.jgraph.ProMJGraph;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.visualizators.GraphViewPanel;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.types.WeightedEventClass;
import org.processmining.plugins.neconformance.ui.simple.EvaluationVisualizator;

public class PetrinetPane
extends JPanel {
    private static final long serialVersionUID = 10027791212343506L;
    private ProMJGraph graph;
    private EvaluationVisualizator evaluationVisualizator;
    private GraphViewPanel graphViewPanel;
    private Set<PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>> drawnEdges;

    public PetrinetPane(EvaluationVisualizator evaluationVisualizator) {
        this.evaluationVisualizator = evaluationVisualizator;
        this.setLayout(new BorderLayout());
        this.initializeGraph();
    }

    private void initializeGraph() {
        this.drawnEdges = new HashSet<PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>>();
        GraphLayoutConnection layoutConnection = new GraphLayoutConnection((DirectedGraph)this.evaluationVisualizator.getResult().net);
        ProMGraphModel model = new ProMGraphModel((DirectedGraph)this.evaluationVisualizator.getResult().net);
        ProMJGraph jGraph = new ProMJGraph(model, new ViewSpecificAttributeMap(), layoutConnection);
        for (DirectedGraphNode node : jGraph.getModel().getGraph().getNodes()) {
            node.getAttributeMap().put("ProM_Vis_attr_showLabel", (Object)true);
            if (node instanceof Place) {
                node.getAttributeMap().put("size", (Object)new Dimension(60, 60));
                continue;
            }
            if (!(node instanceof Transition) || ((Transition)node).isInvisible()) continue;
            node.getAttributeMap().put("size", (Object)new Dimension(80, 60));
        }
        JGraphHierarchicalLayout layout = new JGraphHierarchicalLayout();
        layout.setDeterministic(false);
        layout.setCompactLayout(false);
        layout.setFineTuning(true);
        layout.setParallelEdgeSpacing(15.0);
        layout.setFixRoots(false);
        layout.setOrientation(7);
        if (!layoutConnection.isLayedOut()) {
            JGraphFacade facade = new JGraphFacade((JGraph)jGraph);
            facade.setOrdered(false);
            facade.setEdgePromotion(true);
            facade.setIgnoresCellsInGroups(false);
            facade.setIgnoresHiddenCells(false);
            facade.setIgnoresUnconnectedCells(false);
            facade.setDirected(true);
            facade.resetControlPoints();
            facade.run(layout, true);
            Map nested = facade.createNestedMap(true, true);
            jGraph.getGraphLayoutCache().edit(nested);
            layoutConnection.setLayedOut(true);
        }
        jGraph.setUpdateLayout((JGraphLayout)layout);
        this.graph = jGraph;
        if (this.graphViewPanel != null) {
            this.remove((Component)this.graphViewPanel);
        }
        this.graphViewPanel = new GraphViewPanel((ScalableComponent)this.graph);
        this.add((Component)this.graphViewPanel, "Center");
        this.resetGraph();
    }

    private PetrinetGraph getGraphAsPetrinet() {
        return (PetrinetGraph)this.graph.getModel().getGraph();
    }

    private void resetGraph() {
        for (PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode> e : this.drawnEdges) {
            this.getGraphAsPetrinet().removeArc((PetrinetNode)e.getSource(), (PetrinetNode)e.getParent());
        }
        this.drawnEdges.clear();
        for (DirectedGraphEdge edge : this.getGraphAsPetrinet().getEdges()) {
            edge.getAttributeMap().put("ProM_Vis_attr_edgeColor", (Object)Color.BLACK);
            edge.getAttributeMap().put("ProM_Vis_attr_lineWidth", (Object)Float.valueOf(1.0f));
        }
        for (DirectedGraphNode node : this.getGraphAsPetrinet().getNodes()) {
            node.getAttributeMap().put("ProM_Vis_attr_strokeColor", (Object)Color.BLACK);
            node.getAttributeMap().put("ProM_Vis_attr_lineWidth", (Object)Float.valueOf(1.5f));
            node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.WHITE);
            if (node instanceof Place) {
                node.getAttributeMap().put("ProM_Vis_attr_showLabel", (Object)true);
                node.getAttributeMap().put("ProM_Vis_attr_label", (Object)"");
            }
            if (!(node instanceof Transition) || !((Transition)node).isInvisible()) continue;
            node.getAttributeMap().put("ProM_Vis_attr_showLabel", (Object)false);
            node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.BLACK);
        }
        this.graph.refresh();
    }

    public void annotateGraphReplay(Map<Transition, Integer> normalTransitions, Map<Transition, Integer> forcedTransitions, Map<Transition, Integer> unobservableTransitions, Map<Transition, Integer> skippedTransitions, Map<Place, Integer> markingPlaces, Map<Place, Integer> logmovedPlaces, Map<Transition, Integer> allowedNegativeEvents, Map<Transition, Integer> allowedUnmappedNegativeEvents, Map<Transition, Integer> disallowedGeneralizedEvents, Map<Transition, Integer> disallowedNegativeEvents, Map<Transition, Integer> allowedGeneralizedEvents) {
        for (DirectedGraphNode node : this.getGraphAsPetrinet().getNodes()) {
            Arc a;
            if (node instanceof Place) {
                node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.white);
                node.getAttributeMap().put("ProM_Vis_attr_label", (Object)(markingPlaces.containsKey(node) ? "<html>&bull;</html>" : ""));
            }
            if (!(node instanceof Transition)) continue;
            node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.white);
            node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)"");
            if (normalTransitions.keySet().contains(node)) {
                node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.green);
                node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Normal firings: " + normalTransitions.get(node)));
            }
            if (unobservableTransitions.keySet().contains(node)) {
                node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.gray);
                node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Unobserveable firings: " + unobservableTransitions.get(node)));
            }
            if (skippedTransitions.keySet().contains(node)) {
                node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.pink);
                node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Skipped firings: " + skippedTransitions.get(node)));
            }
            if (forcedTransitions.keySet().contains(node)) {
                node.getAttributeMap().put("ProM_Vis_attr_fillcolor", (Object)Color.red);
                node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Forced firings: " + forcedTransitions.get(node)));
            }
            if (allowedNegativeEvents.keySet().contains(node)) {
                node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Precision violations: " + allowedNegativeEvents.get(node)));
                for (PetrinetEdge ie : this.getGraphAsPetrinet().getInEdges(node)) {
                    a = this.getGraphAsPetrinet().getArc((PetrinetNode)((Place)ie.getSource()), (PetrinetNode)((Transition)node));
                    if (a == null) {
                        a = this.getGraphAsPetrinet().addArc((Place)ie.getSource(), (Transition)node);
                        this.drawnEdges.add((PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>)a);
                    }
                    a.getAttributeMap().put("ProM_Vis_attr_edgeColor", (Object)Color.RED);
                    a.getAttributeMap().put("ProM_Vis_attr_lineWidth", (Object)Float.valueOf(2.0f));
                }
            }
            if (allowedUnmappedNegativeEvents.keySet().contains(node)) {
                node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Precision violations (unmapped): " + allowedUnmappedNegativeEvents.get(node)));
                for (PetrinetEdge ie : this.getGraphAsPetrinet().getInEdges(node)) {
                    a = this.getGraphAsPetrinet().getArc((PetrinetNode)((Place)ie.getSource()), (PetrinetNode)((Transition)node));
                    if (a == null) {
                        a = this.getGraphAsPetrinet().addArc((Place)ie.getSource(), (Transition)node);
                        this.drawnEdges.add((PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>)a);
                    }
                    a.getAttributeMap().put("ProM_Vis_attr_edgeColor", (Object)Color.RED);
                    a.getAttributeMap().put("ProM_Vis_attr_lineWidth", (Object)Float.valueOf(2.0f));
                }
            }
            if (!disallowedNegativeEvents.keySet().contains(node)) continue;
            node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)(node.getAttributeMap().get("ProM_Vis_attr_tooltip") + "\n" + "Precision conformances: " + disallowedNegativeEvents.get(node)));
        }
        this.fixGraphTooltips();
        this.graph.refresh();
    }

    public void notifyGlobalView() {
        this.resetGraph();
        HashMap<Transition, Integer> normalTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> forcedTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> unobservableTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> skippedTransitions = new HashMap<Transition, Integer>();
        HashMap<Place, Integer> markingPlaces = new HashMap<Place, Integer>();
        HashMap<Place, Integer> logmovedPlaces = new HashMap<Place, Integer>();
        HashMap<Transition, Integer> allowedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> allowedUnmappedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> disallowedGeneralizedEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> disallowedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> allowedGeneralizedEvents = new HashMap<Transition, Integer>();
        int selectedTraceIndex = 0;
        while (selectedTraceIndex < this.evaluationVisualizator.getResult().log.size()) {
            XTrace trace = (XTrace)this.evaluationVisualizator.getResult().log.get(selectedTraceIndex);
            ProcessReplayModel<Transition, XEventClass, Marking> replayModel = this.evaluationVisualizator.getResult().replayModels.get(selectedTraceIndex);
            int step = 0;
            while (step < replayModel.size()) {
                this.incrementAnnotationInfo(trace, replayModel, step, normalTransitions, forcedTransitions, unobservableTransitions, skippedTransitions, markingPlaces, logmovedPlaces, allowedNegativeEvents, allowedUnmappedNegativeEvents, disallowedGeneralizedEvents, disallowedNegativeEvents, allowedGeneralizedEvents);
                ++step;
            }
            ++selectedTraceIndex;
        }
        this.annotateGraphReplay(normalTransitions, forcedTransitions, unobservableTransitions, skippedTransitions, new HashMap<Place, Integer>(), logmovedPlaces, allowedNegativeEvents, allowedUnmappedNegativeEvents, disallowedGeneralizedEvents, disallowedNegativeEvents, allowedGeneralizedEvents);
    }

    public void notifyTraceSelection(int selectedTraceIndex) {
        this.resetGraph();
        HashMap<Transition, Integer> normalTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> forcedTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> unobservableTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> skippedTransitions = new HashMap<Transition, Integer>();
        HashMap<Place, Integer> logmovedPlaces = new HashMap<Place, Integer>();
        HashMap<Place, Integer> markingPlaces = new HashMap<Place, Integer>();
        HashMap<Transition, Integer> allowedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> allowedUnmappedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> disallowedGeneralizedEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> disallowedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> allowedGeneralizedEvents = new HashMap<Transition, Integer>();
        XTrace trace = (XTrace)this.evaluationVisualizator.getResult().log.get(selectedTraceIndex);
        ProcessReplayModel<Transition, XEventClass, Marking> replayModel = this.evaluationVisualizator.getResult().replayModels.get(selectedTraceIndex);
        int step = 0;
        while (step < replayModel.size()) {
            this.incrementAnnotationInfo(trace, replayModel, step, normalTransitions, forcedTransitions, unobservableTransitions, skippedTransitions, new HashMap<Place, Integer>(), logmovedPlaces, allowedNegativeEvents, allowedUnmappedNegativeEvents, disallowedGeneralizedEvents, disallowedNegativeEvents, allowedGeneralizedEvents);
            ++step;
        }
        this.annotateGraphReplay(normalTransitions, forcedTransitions, unobservableTransitions, skippedTransitions, markingPlaces, logmovedPlaces, allowedNegativeEvents, allowedUnmappedNegativeEvents, disallowedGeneralizedEvents, disallowedNegativeEvents, allowedGeneralizedEvents);
    }

    public void notifyReplayStepSelection(int selectedTraceIndex, int selectedStepIndex) {
        this.resetGraph();
        HashMap<Transition, Integer> normalTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> forcedTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> unobservableTransitions = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> skippedTransitions = new HashMap<Transition, Integer>();
        HashMap<Place, Integer> logmovedPlaces = new HashMap<Place, Integer>();
        HashMap<Place, Integer> markingPlaces = new HashMap<Place, Integer>();
        HashMap<Transition, Integer> allowedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> allowedUnmappedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> disallowedGeneralizedEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> disallowedNegativeEvents = new HashMap<Transition, Integer>();
        HashMap<Transition, Integer> allowedGeneralizedEvents = new HashMap<Transition, Integer>();
        XTrace trace = (XTrace)this.evaluationVisualizator.getResult().log.get(selectedTraceIndex);
        ProcessReplayModel<Transition, XEventClass, Marking> replayModel = this.evaluationVisualizator.getResult().replayModels.get(selectedTraceIndex);
        this.incrementAnnotationInfo(trace, replayModel, selectedStepIndex, normalTransitions, forcedTransitions, unobservableTransitions, skippedTransitions, markingPlaces, logmovedPlaces, allowedNegativeEvents, allowedUnmappedNegativeEvents, disallowedGeneralizedEvents, disallowedNegativeEvents, allowedGeneralizedEvents);
        this.annotateGraphReplay(normalTransitions, forcedTransitions, unobservableTransitions, skippedTransitions, markingPlaces, logmovedPlaces, allowedNegativeEvents, allowedUnmappedNegativeEvents, disallowedGeneralizedEvents, disallowedNegativeEvents, allowedGeneralizedEvents);
    }

    private void incrementAnnotationInfo(XTrace trace, ProcessReplayModel<Transition, XEventClass, Marking> replayModel, int replayModelStep, Map<Transition, Integer> normalTransitions, Map<Transition, Integer> forcedTransitions, Map<Transition, Integer> unobservableTransitions, Map<Transition, Integer> skippedTransitions, Map<Place, Integer> markingPlaces, Map<Place, Integer> logmovedPlaces, Map<Transition, Integer> allowedNegativeEvents, Map<Transition, Integer> allowedUnmappedNegativeEvents, Map<Transition, Integer> disallowedGeneralizedEvents, Map<Transition, Integer> disallowedNegativeEvents, Map<Transition, Integer> allowedGeneralizedEvents) {
        ProcessReplayModel.ReplayMove type = replayModel.getReplayMove(replayModelStep);
        Set<Transition> orphanedModelElements = replayModel.getOrphanedModelElements();
        Marking marking = replayModel.getModelState(replayModelStep - 1);
        for (Place p : marking) {
            markingPlaces.put(p, marking.occurrences((Object)p));
        }
        switch (type) {
            case BOTH_SYNCHRONOUS: {
                if (!normalTransitions.containsKey(replayModel.getModelElement(replayModelStep))) {
                    normalTransitions.put(replayModel.getModelElement(replayModelStep), 0);
                }
                normalTransitions.put(replayModel.getModelElement(replayModelStep), normalTransitions.get(replayModel.getModelElement(replayModelStep)) + 1);
                break;
            }
            case BOTH_FORCED: {
                if (!forcedTransitions.containsKey(replayModel.getModelElement(replayModelStep))) {
                    forcedTransitions.put(replayModel.getModelElement(replayModelStep), 0);
                }
                forcedTransitions.put(replayModel.getModelElement(replayModelStep), forcedTransitions.get(replayModel.getModelElement(replayModelStep)) + 1);
                break;
            }
            case LOGONLY_INSERTED: {
                Marking s = replayModel.getModelState(replayModelStep);
                for (Place p : s) {
                    if (!logmovedPlaces.containsKey(p)) {
                        logmovedPlaces.put(p, 0);
                    }
                    logmovedPlaces.put(p, logmovedPlaces.get(p) + 1);
                }
                break;
            }
            case MODELONLY_SKIPPED: {
                if (!skippedTransitions.containsKey(replayModel.getModelElement(replayModelStep))) {
                    skippedTransitions.put(replayModel.getModelElement(replayModelStep), 0);
                }
                skippedTransitions.put(replayModel.getModelElement(replayModelStep), skippedTransitions.get(replayModel.getModelElement(replayModelStep)) + 1);
                break;
            }
            case MODELONLY_UNOBSERVABLE: {
                if (!unobservableTransitions.containsKey(replayModel.getModelElement(replayModelStep))) {
                    unobservableTransitions.put(replayModel.getModelElement(replayModelStep), 0);
                }
                unobservableTransitions.put(replayModel.getModelElement(replayModelStep), unobservableTransitions.get(replayModel.getModelElement(replayModelStep)) + 1);
                break;
            }
        }
        if (type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS) || type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_FORCED) || type.equals((Object)ProcessReplayModel.ReplayMove.LOGONLY_INSERTED)) {
            int currentPositionInTrace = this.getTracePositionForReplayStep(replayModel, replayModelStep);
            int latestNonInvisibleStep = replayModelStep - 1;
            while (latestNonInvisibleStep >= 0) {
                if (!replayModel.getReplayMove(latestNonInvisibleStep).equals((Object)ProcessReplayModel.ReplayMove.MODELONLY_UNOBSERVABLE)) break;
                --latestNonInvisibleStep;
            }
            Set<XEventClass> executables = latestNonInvisibleStep < 0 ? replayModel.getExecutableLogElements(replayModel.getInitialState()) : replayModel.getExecutableLogElements(replayModel.getModelState(latestNonInvisibleStep));
            Set modelExecutables = latestNonInvisibleStep < 0 ? ((PetrinetReplayModel)replayModel).getExecutableModelElements(replayModel.getInitialState()) : ((PetrinetReplayModel)replayModel).getExecutableModelElements(replayModel.getModelState(latestNonInvisibleStep));
            Set<WeightedEventClass> negativeevents = this.evaluationVisualizator.getResult().inducer.getNegativeEvents(trace, currentPositionInTrace);
            Set<WeightedEventClass> generalizedevents = this.evaluationVisualizator.getResult().inducer.getGeneralizedEvents(trace, currentPositionInTrace);
            for (Transition tr : orphanedModelElements) {
                if (!modelExecutables.contains(tr)) continue;
                if (!allowedUnmappedNegativeEvents.containsKey(tr)) {
                    allowedUnmappedNegativeEvents.put(tr, 0);
                }
                allowedUnmappedNegativeEvents.put(tr, allowedUnmappedNegativeEvents.get(tr) + 1);
            }
            for (WeightedEventClass ec : negativeevents) {
                for (Transition tr : this.evaluationVisualizator.getResult().mapper.getTransitionsForActivity(ec.eventClass.getId())) {
                    if (executables.contains(ec.eventClass)) {
                        if (!allowedNegativeEvents.containsKey(tr)) {
                            allowedNegativeEvents.put(tr, 0);
                        }
                        allowedNegativeEvents.put(tr, allowedNegativeEvents.get(tr) + 1);
                        continue;
                    }
                    if (!disallowedNegativeEvents.containsKey(tr)) {
                        disallowedNegativeEvents.put(tr, 0);
                    }
                    disallowedNegativeEvents.put(tr, disallowedNegativeEvents.get(tr) + 1);
                }
            }
            for (WeightedEventClass ec : generalizedevents) {
                for (Transition tr : this.evaluationVisualizator.getResult().mapper.getTransitionsForActivity(ec.eventClass.getId())) {
                    if (executables.contains(ec.eventClass)) {
                        if (!disallowedGeneralizedEvents.containsKey(tr)) {
                            disallowedGeneralizedEvents.put(tr, 0);
                        }
                        disallowedGeneralizedEvents.put(tr, disallowedGeneralizedEvents.get(tr) + 1);
                        continue;
                    }
                    if (!allowedGeneralizedEvents.containsKey(tr)) {
                        allowedGeneralizedEvents.put(tr, 0);
                    }
                    allowedGeneralizedEvents.put(tr, allowedGeneralizedEvents.get(tr) + 1);
                }
            }
        }
    }

    private int getTracePositionForReplayStep(ProcessReplayModel<Transition, XEventClass, Marking> replayModel, int replayStep) {
        int positionInTrace = -1;
        int step = 0;
        while (step <= replayStep) {
            ProcessReplayModel.ReplayMove type = replayModel.getReplayMove(step);
            if (type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS) || type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_FORCED) || type.equals((Object)ProcessReplayModel.ReplayMove.LOGONLY_INSERTED)) {
                ++positionInTrace;
            }
            ++step;
        }
        return positionInTrace;
    }

    private void fixGraphTooltips() {
        for (DirectedGraphNode node : this.graph.getModel().getGraph().getNodes()) {
            if (!node.getAttributeMap().containsKey("ProM_Vis_attr_tooltip")) continue;
            String tip = node.getAttributeMap().get("ProM_Vis_attr_tooltip").toString();
            tip = tip.replaceAll("<html>", "");
            tip = tip.replaceAll("</html>", "");
            tip = tip.replaceAll("<br>", "");
            tip = tip.replaceAll("\\n", "<br>\n");
            tip = "<html>" + tip + "</html>";
            node.getAttributeMap().put("ProM_Vis_attr_tooltip", (Object)tip);
        }
    }
}

