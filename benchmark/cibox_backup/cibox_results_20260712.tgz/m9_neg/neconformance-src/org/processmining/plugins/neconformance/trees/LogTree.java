/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.trees;

import java.util.List;

public interface LogTree {
    public int getLongestMatchingWindowSize(List<String> var1, String var2);

    public int getShortestMatchingWindowSize(List<String> var1, String var2);
}

