/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.ui.graphics;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import javax.swing.JLabel;
import org.processmining.plugins.neconformance.ui.graphics.ITransitionPDecorator;

public class TransConfDecorator
implements ITransitionPDecorator {
    private Color[] colors;
    private int[] values;
    private boolean lightColorLabel = false;
    private String label;
    private static Font DEFFONT = new Font("SansSerif", 0, 16);
    private static int MARGIN = 3;

    private TransConfDecorator() {
    }

    public TransConfDecorator(int[] values, Color[] colors, String label, boolean lightColorLabel) {
        this.values = values;
        this.colors = colors;
        this.label = label;
        this.lightColorLabel = lightColorLabel;
    }

    @Override
    public void decorate(Graphics2D g2d, double x, double y, double width, double height) {
        int total = 0;
        int[] nArray = this.values;
        int n = this.values.length;
        int n2 = 0;
        while (n2 < n) {
            int i = nArray[n2];
            total += i;
            ++n2;
        }
        int lastx = (int)x;
        g2d.setColor(Color.white);
        g2d.fillRect((int)x, (int)y, (int)width, (int)height);
        int i = 0;
        while (i < this.values.length) {
            int w;
            if (this.values[i] > 0 && (w = (int)((double)this.values[i] * width / (double)total)) > 0) {
                g2d.setColor(this.colors[i]);
                g2d.fillRect(lastx, (int)y, w, (int)height);
                lastx += w;
            }
            ++i;
        }
        g2d.setColor(Color.black);
        g2d.drawRect((int)x, (int)y, (int)width, (int)height);
        StringBuilder sb = new StringBuilder();
        sb.append("<html><div style=\"align:center;width:" + (width - (double)(2 * MARGIN)) + "px;\">");
        sb.append(this.label.replace("+complete", "").replace("\\ncomplete", ""));
        sb.append("</div></html>");
        JLabel nodeName = new JLabel(sb.toString());
        sb.setLength(0);
        FontMetrics metrics = g2d.getFontMetrics(DEFFONT);
        int hgt = (int)height - 1 * MARGIN;
        int adv = metrics.stringWidth(nodeName.getText());
        int labelX = (int)x + MARGIN;
        int labelY = (int)y + 1;
        int labelW = adv;
        int labelH = hgt;
        nodeName.setPreferredSize(new Dimension(labelW, labelH));
        nodeName.setSize(new Dimension(labelW, labelH));
        nodeName.setFont(DEFFONT);
        nodeName.validate();
        if (this.lightColorLabel) {
            nodeName.setForeground(Color.WHITE);
        } else {
            nodeName.setForeground(Color.BLACK);
        }
        nodeName.paint(g2d.create(labelX, labelY, labelW, labelH));
    }
}

