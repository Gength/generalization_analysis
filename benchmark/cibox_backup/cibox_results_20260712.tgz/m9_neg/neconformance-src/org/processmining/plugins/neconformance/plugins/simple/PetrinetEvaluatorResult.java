/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.model.XLog
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 */
package org.processmining.plugins.neconformance.plugins.simple;

import java.util.List;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.model.XLog;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.neconformance.metrics.impl.BehavioralRecallMetric;
import org.processmining.plugins.neconformance.metrics.impl.BehavioralWeightedPrecisionMetric;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.negativeevents.impl.LogTreeWeightedNegativeEventInducer;

public class PetrinetEvaluatorResult {
    public LogTreeWeightedNegativeEventInducer inducer;
    public XLog log;
    public Petrinet net;
    public PetrinetLogMapper mapper;
    public List<ProcessReplayModel<Transition, XEventClass, Marking>> replayModels;
    public BehavioralRecallMetric behavioralRecallMetric;
    public BehavioralWeightedPrecisionMetric behavioralPrecisionMetric;
    public Marking marking;
}

