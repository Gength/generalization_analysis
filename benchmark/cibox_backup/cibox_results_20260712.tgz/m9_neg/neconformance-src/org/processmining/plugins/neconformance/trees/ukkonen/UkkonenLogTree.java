/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClassifier
 *  org.deckfour.xes.info.impl.XLogInfoImpl
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.plugins.kutoolbox.utils.LogUtils
 */
package org.processmining.plugins.neconformance.trees.ukkonen;

import java.util.Collections;
import java.util.List;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.info.impl.XLogInfoImpl;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.plugins.kutoolbox.utils.LogUtils;
import org.processmining.plugins.neconformance.trees.LogTree;
import org.processmining.plugins.neconformance.trees.ukkonen.Cursor;
import org.processmining.plugins.neconformance.trees.ukkonen.SuffixTree;

public class UkkonenLogTree
implements LogTree {
    private XLog log;
    private XEventClassifier classifier;
    private SuffixTree<String, List<String>> suffixTree;

    public UkkonenLogTree(XLog log) {
        this(log, XLogInfoImpl.STANDARD_CLASSIFIER);
    }

    public UkkonenLogTree(XLog log, XEventClassifier classifier) {
        this.log = log;
        this.classifier = classifier;
        this.suffixTree = new SuffixTree();
        this.constructSuffixtree();
    }

    private void constructSuffixtree() {
        int t = 0;
        while (t < this.log.size()) {
            XTrace trace = (XTrace)this.log.get(t);
            this.addTraceToSuffixTree(trace);
            ++t;
        }
    }

    public void addTraceToSuffixTree(XTrace trace) {
        List traceSuffixed = LogUtils.getTraceEventClassSequence((XTrace)trace, (XEventClassifier)this.classifier);
        Collections.reverse(traceSuffixed);
        this.suffixTree.add(traceSuffixed);
    }

    @Override
    public int getLongestMatchingWindowSize(List<String> window, String entryClass) {
        Cursor<String, List<String>> cursor = new Cursor<String, List<String>>(this.suffixTree);
        if (!cursor.proceedTo(entryClass)) {
            System.err.println("Ukkonen tree could not enter entry class: " + entryClass + ", returning 0");
            return 0;
        }
        int windowPos = window.size() - 1;
        while (windowPos >= 0) {
            if (!cursor.proceedTo(window.get(windowPos))) break;
            if (windowPos == 0) {
                return window.size();
            }
            --windowPos;
        }
        return window.size() - windowPos - 1;
    }

    @Override
    public int getShortestMatchingWindowSize(List<String> window, String entryClass) {
        Cursor<String, List<String>> cursor = new Cursor<String, List<String>>(this.suffixTree);
        if (!cursor.proceedTo(entryClass)) {
            System.err.println("Ukkonen tree could not enter entry class: " + entryClass + ", returning 0");
            return 0;
        }
        int windowPos = window.size() - 1;
        while (windowPos >= 0) {
            if (!cursor.hasSingleContinuation()) {
                return window.size() - windowPos - 1;
            }
            if (!cursor.proceedTo(window.get(windowPos))) break;
            if (windowPos == 0) {
                return window.size();
            }
            --windowPos;
        }
        return window.size() - windowPos - 1;
    }
}

