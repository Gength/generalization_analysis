/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.ui.graphics;

import java.awt.Graphics2D;

public interface IPlacePDecorator {
    public void decorate(Graphics2D var1, double var2, double var4, double var6, double var8);
}

