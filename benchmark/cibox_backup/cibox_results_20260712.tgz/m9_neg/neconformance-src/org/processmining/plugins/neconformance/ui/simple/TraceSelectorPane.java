/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.extension.std.XConceptExtension
 *  org.deckfour.xes.model.XAttributable
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 */
package org.processmining.plugins.neconformance.ui.simple;

import java.awt.BorderLayout;
import java.util.ArrayList;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.extension.std.XConceptExtension;
import org.deckfour.xes.model.XAttributable;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.ui.simple.EvaluationVisualizator;

public class TraceSelectorPane
extends JPanel {
    private static final long serialVersionUID = -197086735832537712L;

    public TraceSelectorPane(final EvaluationVisualizator evaluationVisualizator) {
        this.setLayout(new BorderLayout());
        final JList<String> traceList = new JList<String>();
        ArrayList<String> traces = new ArrayList<String>();
        traces.add("-- Global overview --(Recall: " + evaluationVisualizator.getResult().behavioralRecallMetric.getValue() + " | Precision: " + evaluationVisualizator.getResult().behavioralPrecisionMetric.getValue() + ")");
        int t = 0;
        while (t < evaluationVisualizator.getResult().log.size()) {
            String name = XConceptExtension.instance().extractName((XAttributable)evaluationVisualizator.getResult().log.get(t));
            ProcessReplayModel<Transition, XEventClass, Marking> replayModel = evaluationVisualizator.getResult().replayModels.get(t);
            boolean sync = false;
            boolean forc = false;
            boolean inse = false;
            boolean skip = false;
            boolean unob = false;
            int step = 0;
            while (step < replayModel.size()) {
                ProcessReplayModel.ReplayMove type = replayModel.getReplayMove(step);
                switch (type) {
                    case BOTH_SYNCHRONOUS: {
                        sync = true;
                        break;
                    }
                    case BOTH_FORCED: {
                        forc = true;
                        break;
                    }
                    case LOGONLY_INSERTED: {
                        inse = true;
                        break;
                    }
                    case MODELONLY_SKIPPED: {
                        skip = true;
                        break;
                    }
                    case MODELONLY_UNOBSERVABLE: {
                        unob = true;
                        break;
                    }
                }
                ++step;
            }
            if (sync) {
                name = String.valueOf(name) + " [both-ok]";
            }
            if (forc) {
                name = String.valueOf(name) + " [both-force]";
            }
            if (inse) {
                name = String.valueOf(name) + " [logonly]";
            }
            if (skip) {
                name = String.valueOf(name) + " [modelonly-skip]";
            }
            if (unob) {
                name = String.valueOf(name) + " [modelonly-invi]";
            }
            traces.add(name);
            ++t;
        }
        traceList.setListData(traces.toArray(new String[0]));
        traceList.addListSelectionListener(new ListSelectionListener(){

            @Override
            public void valueChanged(ListSelectionEvent arg0) {
                evaluationVisualizator.notifyTraceSelection(traceList.getSelectedIndex());
            }
        });
        JScrollPane scrollPane = new JScrollPane(traceList);
        this.add(scrollPane);
    }
}

