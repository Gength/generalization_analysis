/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.trees.suffixtree;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class SuffixTreeNode {
    private int id;
    private Map<String, Set<SuffixTreeNode>> edges;

    public SuffixTreeNode(int id) {
        this.id = id;
        this.edges = new HashMap<String, Set<SuffixTreeNode>>();
    }

    public int getId() {
        return this.id;
    }

    public int hashCode() {
        int prime = 31;
        int result = 1;
        result = 31 * result + this.id;
        return result;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        SuffixTreeNode other = (SuffixTreeNode)obj;
        return this.id == other.id;
    }

    public String toString() {
        return "SuffixTreeNode [id=" + this.id + "]";
    }

    public void addEdge(String transitionName, SuffixTreeNode node) {
        if (!this.edges.containsKey(transitionName)) {
            this.edges.put(transitionName, new HashSet());
        }
        this.edges.get(transitionName).add(node);
    }

    public int nrNodesOut() {
        return this.edges.size();
    }

    public Set<SuffixTreeNode> getNodesOut(String transitionName) {
        if (!this.edges.containsKey(transitionName)) {
            return null;
        }
        return this.edges.get(transitionName);
    }
}

