/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 */
package org.processmining.plugins.neconformance.metrics.impl;

import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.model.XTrace;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.neconformance.models.impl.TraceReplayRunnable;

class ReplayTask {
    public TraceReplayRunnable<Transition, XEventClass, Marking> runnable;
    public XTrace trace;
    public int times;

    public ReplayTask(TraceReplayRunnable<Transition, XEventClass, Marking> runnable, XTrace trace, int times) {
        this.runnable = runnable;
        this.trace = trace;
        this.times = times;
    }
}

