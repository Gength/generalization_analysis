/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.models.graphbased.directed.AbstractDirectedGraph
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetEdge
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetNode
 *  org.processmining.models.graphbased.directed.petrinet.impl.ResetInhibitorNetImpl
 */
package org.processmining.plugins.neconformance.ui.graphics;

import java.awt.Dimension;
import org.processmining.models.graphbased.directed.AbstractDirectedGraph;
import org.processmining.models.graphbased.directed.petrinet.PetrinetEdge;
import org.processmining.models.graphbased.directed.petrinet.PetrinetNode;
import org.processmining.models.graphbased.directed.petrinet.impl.ResetInhibitorNetImpl;
import org.processmining.plugins.neconformance.ui.graphics.PlaceP;
import org.processmining.plugins.neconformance.ui.graphics.TransitionP;

public class PetrinetGraphP
extends ResetInhibitorNetImpl {
    public PetrinetGraphP(String label) {
        super(label);
    }

    public synchronized TransitionP addTransition(String label) {
        TransitionP t = new TransitionP(label, (AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>>)this);
        this.transitions.add(t);
        this.graphElementAdded((Object)t);
        return t;
    }

    public synchronized TransitionP addTransition(String label, Dimension dimension) {
        TransitionP t = new TransitionP(label, (AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>>)this, dimension);
        this.transitions.add(t);
        this.graphElementAdded((Object)t);
        return t;
    }

    public synchronized PlaceP addPlace(String label) {
        PlaceP p = new PlaceP(label, (AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>>)this);
        this.places.add(p);
        this.graphElementAdded((Object)p);
        return p;
    }

    public synchronized PlaceP addPlace(String label, Dimension dimension) {
        PlaceP p = new PlaceP(label, (AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>>)this, dimension);
        this.places.add(p);
        this.graphElementAdded((Object)p);
        return p;
    }
}

