/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetNode
 *  org.processmining.models.graphbased.directed.petrinet.elements.Arc
 *  org.processmining.models.shapes.Decorated
 */
package org.processmining.plugins.neconformance.ui.graphics;

import java.awt.Graphics2D;
import org.processmining.models.graphbased.directed.petrinet.PetrinetNode;
import org.processmining.models.graphbased.directed.petrinet.elements.Arc;
import org.processmining.models.shapes.Decorated;
import org.processmining.plugins.neconformance.ui.graphics.IEdgePDecorator;

public class EdgeP
extends Arc
implements Decorated {
    protected IEdgePDecorator decorator;

    public EdgeP(PetrinetNode source, PetrinetNode target, int weight) {
        super(source, target, weight);
    }

    public void decorate(Graphics2D g2d, double x, double y, double width, double height) {
        if (this.decorator != null) {
            this.decorator.decorate(g2d, x, y, width, height);
        }
    }
}

