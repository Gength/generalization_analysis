/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.model.XTrace
 */
package org.processmining.plugins.neconformance.negativeevents.impl;

import java.util.HashSet;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.model.XTrace;
import org.processmining.plugins.neconformance.bags.LogBag;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;
import org.processmining.plugins.neconformance.types.WeightedEventClass;

public class LogBagWeightedNegativeEventInducer
extends AbstractNegativeEventInducer {
    private LogBag logBag;
    private boolean useWeighted = true;
    private int negWindowSize = -1;
    private int genWindowSize = -1;
    private boolean useBothWindowRatios = true;
    private boolean useWindowOccurrenceCut = false;
    private boolean returnZeroEvents = false;

    public LogBagWeightedNegativeEventInducer(XEventClasses classes, Set<XEventClass> startingClasses, LogBag logBag) {
        super(classes, startingClasses);
        this.logBag = logBag;
    }

    public Set<WeightedEventClass> getWeightedNegativeEvents(XTrace trace, int position, boolean isGeneralization) {
        int windowSize = isGeneralization ? this.genWindowSize : this.negWindowSize;
        Set<String> classBag = this.getEventBagBeforePosition(trace, position, windowSize, this.useWindowOccurrenceCut);
        String positiveClass = this.getEventClassAtPosition(trace, position);
        HashSet<WeightedEventClass> eventSet = new HashSet<WeightedEventClass>();
        for (XEventClass ec : this.classAlphabet.getClasses()) {
            double mws;
            if (ec.getId().equals(positiveClass)) continue;
            double weight = 0.0;
            double lenw = classBag.size();
            if (classBag.size() == 0) {
                weight = isGeneralization && this.isStartingClass(ec) || !isGeneralization && !this.isStartingClass(ec) ? 1.0 : 0.0;
            } else if (isGeneralization) {
                double d = mws = this.useBothWindowRatios ? (double)this.logBag.getSmallestSharedSize(classBag, ec.getId()) : (double)this.logBag.getLargestSharedBagSize(classBag, ec.getId());
                weight = this.useWeighted ? mws / lenw : (mws >= lenw ? 1.0 : 0.0);
            } else {
                mws = this.logBag.getLargestSharedBagSize(classBag, ec.getId());
                double d = this.useWeighted ? (lenw - mws) / lenw : (weight = mws >= lenw ? 0.0 : 1.0);
            }
            if (!(weight > 0.0) && !this.returnZeroEvents) continue;
            eventSet.add(new WeightedEventClass(ec, weight));
        }
        return eventSet;
    }

    @Override
    public Set<WeightedEventClass> getNegativeEvents(XTrace trace, int position) {
        return this.getWeightedNegativeEvents(trace, position, false);
    }

    @Override
    public Set<WeightedEventClass> getGeneralizedEvents(XTrace trace, int position) {
        return this.getWeightedNegativeEvents(trace, position, true);
    }

    public LogBag getLogTree() {
        return this.logBag;
    }

    public void setLogBag(LogBag logBag) {
        this.logBag = logBag;
    }

    public boolean isUseWeighted() {
        return this.useWeighted;
    }

    public void setUseWeighted(boolean useWeighted) {
        this.useWeighted = useWeighted;
    }

    public int getNegWindowSize() {
        return this.negWindowSize;
    }

    public void setNegWindowSize(int negWindowSize) {
        this.negWindowSize = negWindowSize;
    }

    public int getGenWindowSize() {
        return this.genWindowSize;
    }

    public void setGenWindowSize(int genWindowSize) {
        this.genWindowSize = genWindowSize;
    }

    public boolean isUseBothWindowRatios() {
        return this.useBothWindowRatios;
    }

    public void setUseBothWindowRatios(boolean useBothWindowRatios) {
        this.useBothWindowRatios = useBothWindowRatios;
    }

    public boolean isUseWindowOccurrenceCut() {
        return this.useWindowOccurrenceCut;
    }

    public void setUseWindowOccurrenceCut(boolean useWindowOccurrenceCut) {
        this.useWindowOccurrenceCut = useWindowOccurrenceCut;
    }

    public boolean isReturnZeroEvents() {
        return this.returnZeroEvents;
    }

    public void setReturnZeroEvents(boolean returnZeroEvents) {
        this.returnZeroEvents = returnZeroEvents;
    }
}

