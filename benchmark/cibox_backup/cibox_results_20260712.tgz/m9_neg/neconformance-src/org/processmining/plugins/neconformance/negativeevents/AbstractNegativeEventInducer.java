/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.classification.XEventClassifier
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.plugins.kutoolbox.utils.LogUtils
 */
package org.processmining.plugins.neconformance.negativeevents;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.plugins.kutoolbox.utils.LogUtils;
import org.processmining.plugins.neconformance.negativeevents.NegativeEventInducer;
import org.processmining.plugins.neconformance.types.WeightedEventClass;

public abstract class AbstractNegativeEventInducer
implements NegativeEventInducer {
    protected XEventClasses classAlphabet;
    protected Set<XEventClass> startingClasses;

    protected AbstractNegativeEventInducer(XEventClasses classes, Set<XEventClass> startingClasses) {
        this.classAlphabet = classes;
        this.startingClasses = startingClasses;
    }

    public String getEventClassAtPosition(XTrace trace, int position) {
        return this.classAlphabet.getClassifier().getClassIdentity((XEvent)trace.get(position));
    }

    public List<String> getEventWindowBeforePosition(XTrace trace, int position, int windowSize, boolean stopAtNextOccurrence) {
        List fullSequence = LogUtils.getTraceEventClassSequence((XTrace)trace, (XEventClassifier)this.classAlphabet.getClassifier());
        int startPos = position - windowSize;
        if (windowSize < 0 || startPos < 0) {
            startPos = 0;
        }
        if (stopAtNextOccurrence) {
            int checkPos = position - 1;
            while (checkPos >= startPos) {
                if (((String)fullSequence.get(checkPos)).equals(fullSequence.get(position))) {
                    startPos = checkPos;
                    break;
                }
                --checkPos;
            }
        }
        return new ArrayList<String>(fullSequence.subList(startPos, position));
    }

    public Set<String> getEventBagBeforePosition(XTrace trace, int position, int windowSize, boolean stopAtNextOccurrence) {
        return new HashSet<String>(this.getEventWindowBeforePosition(trace, position, windowSize, stopAtNextOccurrence));
    }

    @Override
    public abstract Set<WeightedEventClass> getNegativeEvents(XTrace var1, int var2);

    @Override
    public abstract Set<WeightedEventClass> getGeneralizedEvents(XTrace var1, int var2);

    public XEventClasses getClassAlphabet() {
        return this.classAlphabet;
    }

    public boolean isStartingClass(XEventClass clazz) {
        return this.startingClasses.contains(clazz);
    }

    public static Set<XEventClass> deriveStartingClasses(XEventClasses classAlphabet, XLog log) {
        HashSet<XEventClass> starters = new HashSet<XEventClass>();
        for (XTrace t : log) {
            if (t.size() <= 0) continue;
            starters.add(classAlphabet.getClassOf((XEvent)t.get(0)));
        }
        return starters;
    }
}

