/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.factory.XFactory
 *  org.deckfour.xes.factory.XFactoryRegistry
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 *  org.deckfour.xes.model.impl.XAttributeLiteralImpl
 *  org.deckfour.xes.model.impl.XEventImpl
 *  org.processmining.framework.plugin.PluginContext
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetGraph
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.connectionfactories.logpetrinet.EvClassLogPetrinetConnectionFactoryUI
 *  org.processmining.plugins.connectionfactories.logpetrinet.TransEvClassMapping
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 *  org.processmining.plugins.kutoolbox.utils.FakePluginContext
 *  org.processmining.plugins.kutoolbox.utils.LogUtils
 *  org.processmining.plugins.kutoolbox.utils.PetrinetUtils
 *  org.processmining.plugins.petrinet.replayer.PNLogReplayer
 *  org.processmining.plugins.petrinet.replayer.algorithms.IPNReplayAlgorithm
 *  org.processmining.plugins.petrinet.replayer.algorithms.IPNReplayParameter
 *  org.processmining.plugins.petrinet.replayer.algorithms.costbasedprefix.CostBasedPrefixAlg
 *  org.processmining.plugins.petrinet.replayer.algorithms.costbasedprefix.CostBasedPrefixParam
 *  org.processmining.plugins.petrinet.replayresult.PNRepResult
 *  org.processmining.plugins.petrinet.replayresult.StepTypes
 *  org.processmining.plugins.replayer.replayresult.SyncReplayResult
 */
package org.processmining.plugins.neconformance.models.impl;

import java.util.Collection;
import java.util.List;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.factory.XFactoryRegistry;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.deckfour.xes.model.impl.XAttributeLiteralImpl;
import org.deckfour.xes.model.impl.XEventImpl;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.PetrinetGraph;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.connectionfactories.logpetrinet.EvClassLogPetrinetConnectionFactoryUI;
import org.processmining.plugins.connectionfactories.logpetrinet.TransEvClassMapping;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.kutoolbox.utils.FakePluginContext;
import org.processmining.plugins.kutoolbox.utils.LogUtils;
import org.processmining.plugins.kutoolbox.utils.PetrinetUtils;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.utils.PetrinetReplayUtils;
import org.processmining.plugins.petrinet.replayer.PNLogReplayer;
import org.processmining.plugins.petrinet.replayer.algorithms.IPNReplayAlgorithm;
import org.processmining.plugins.petrinet.replayer.algorithms.IPNReplayParameter;
import org.processmining.plugins.petrinet.replayer.algorithms.costbasedprefix.CostBasedPrefixAlg;
import org.processmining.plugins.petrinet.replayer.algorithms.costbasedprefix.CostBasedPrefixParam;
import org.processmining.plugins.petrinet.replayresult.PNRepResult;
import org.processmining.plugins.petrinet.replayresult.StepTypes;
import org.processmining.plugins.replayer.replayresult.SyncReplayResult;

public class AryaPetrinetReplayModel
extends PetrinetReplayModel {
    protected XEventClasses eventClasses;
    protected IPNReplayAlgorithm chosenAlgorithm;
    private PNRepResult aryaReplayResult;

    public AryaPetrinetReplayModel(Petrinet net, XEventClasses eventClasses, Marking initialMarking, PetrinetLogMapper mapping) {
        super(net, initialMarking, mapping);
        this.eventClasses = eventClasses;
        this.chosenAlgorithm = new CostBasedPrefixAlg();
    }

    public AryaPetrinetReplayModel(AryaPetrinetReplayModel toClone) {
        this(toClone.getPetrinet(), toClone.getEventClasses(), (Marking)toClone.getInitialState(), toClone.getMapping());
    }

    @Override
    public void reset() {
        super.reset();
        this.aryaReplayResult = null;
        this.currentMarking = new Marking();
        this.currentMarking.addAll((Collection)((Marking)this.initialState).toList());
    }

    @Override
    public void replay(List<XEventClass> trace) {
        this.reset();
        XFactory factory = (XFactory)XFactoryRegistry.instance().currentDefault();
        XLog log = LogUtils.newLog((String)"Dummy Log");
        XTrace xtrace = factory.createTrace();
        for (XEventClass ec : trace) {
            xtrace.add((Object)this.makeEvent(ec));
        }
        log.add((Object)xtrace);
        TransEvClassMapping transEvMapping = this.getTransEvClassMapping(this.mapping, this.net);
        CostBasedPrefixParam parameters = new CostBasedPrefixParam();
        parameters.setCreateConn(false);
        parameters.setGUIMode(false);
        parameters.setInitialMarking((Marking)this.getInitialState());
        parameters.setFinalMarkings(new Marking[]{PetrinetUtils.getFinalMarking((Petrinet)this.net)});
        parameters.setInappropriateTransFireCost(Integer.valueOf(1));
        boolean satisfied = this.chosenAlgorithm.isAllReqSatisfied(null, (PetrinetGraph)this.net, log, transEvMapping, (IPNReplayParameter)parameters);
        PNLogReplayer replayer = new PNLogReplayer();
        try {
            this.aryaReplayResult = replayer.replayLog((PluginContext)new FakePluginContext(), this.net, log, transEvMapping, this.chosenAlgorithm, (IPNReplayParameter)parameters);
        }
        catch (Exception e) {
            this.aryaReplayResult = null;
            System.err.println("WARNING: Arya failed to replay");
            e.printStackTrace();
            return;
        }
        if (this.aryaReplayResult == null) {
            System.err.println("WARNING: Arya failed to replay (no exception message available)");
            System.err.println("Satisfaction state: " + satisfied);
            return;
        }
        SyncReplayResult syncResult = (SyncReplayResult)this.aryaReplayResult.iterator().next();
        int i = 0;
        while (i < syncResult.getStepTypes().size()) {
            ProcessReplayModel.ReplayMove move = null;
            Transition t = null;
            XEventClass c = null;
            StepTypes stepType = (StepTypes)syncResult.getStepTypes().get(i);
            switch (stepType) {
                case LMGOOD: {
                    t = (Transition)syncResult.getNodeInstance().get(i);
                    c = (XEventClass)this.mapping.get((Object)t);
                    move = ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS;
                    break;
                }
                case LMNOGOOD: {
                    t = (Transition)syncResult.getNodeInstance().get(i);
                    c = (XEventClass)this.mapping.get((Object)t);
                    move = ProcessReplayModel.ReplayMove.BOTH_FORCED;
                    break;
                }
                case MINVI: {
                    t = (Transition)syncResult.getNodeInstance().get(i);
                    c = null;
                    move = ProcessReplayModel.ReplayMove.MODELONLY_UNOBSERVABLE;
                    break;
                }
                case MREAL: {
                    t = (Transition)syncResult.getNodeInstance().get(i);
                    c = null;
                    move = ProcessReplayModel.ReplayMove.MODELONLY_SKIPPED;
                    break;
                }
                case L: {
                    t = null;
                    String s = syncResult.getNodeInstance().get(i).toString();
                    c = this.mapping.getEventClass(s);
                    move = ProcessReplayModel.ReplayMove.LOGONLY_INSERTED;
                    break;
                }
            }
            Marking m = this.currentMarking;
            if (t != null) {
                m = PetrinetReplayUtils.getMarkingAfterFire(this.net, m, t);
            }
            this.addReplayStep(move, t, c, m);
            this.currentMarking = m;
            ++i;
        }
    }

    private XEvent makeEvent(XEventClass eventClass) {
        XEventImpl event = new XEventImpl();
        String[] keys = this.eventClasses.getClassifier().getDefiningAttributeKeys();
        String[] values = eventClass.toString().split("\\+");
        int i = 0;
        while (i < keys.length) {
            event.getAttributes().put((Object)keys[i], (Object)new XAttributeLiteralImpl(keys[i], values[i]));
            ++i;
        }
        return event;
    }

    private TransEvClassMapping getTransEvClassMapping(PetrinetLogMapper mapping, Petrinet net) {
        TransEvClassMapping transEvClassMapping = new TransEvClassMapping(mapping.getEventClassifier(), EvClassLogPetrinetConnectionFactoryUI.DUMMY);
        for (Transition transition : net.getTransitions()) {
            if (mapping.get((Object)transition) == null) {
                transEvClassMapping.put((Object)transition, (Object)EvClassLogPetrinetConnectionFactoryUI.DUMMY);
                continue;
            }
            if (((XEventClass)mapping.get((Object)transition)).equals((Object)PetrinetLogMapper.BLOCKING_CLASS)) {
                transEvClassMapping.put((Object)transition, (Object)EvClassLogPetrinetConnectionFactoryUI.DUMMY);
                continue;
            }
            transEvClassMapping.put((Object)transition, (Object)((XEventClass)mapping.get((Object)transition)));
        }
        return transEvClassMapping;
    }

    public XEventClasses getEventClasses() {
        return this.eventClasses;
    }

    public IPNReplayAlgorithm getChosenAlgorithm() {
        return this.chosenAlgorithm;
    }

    public void setChosenAlgorithm(IPNReplayAlgorithm chosenAlgorithm) {
        this.chosenAlgorithm = chosenAlgorithm;
    }

    public PNRepResult getAryaReplayResult() {
        return this.aryaReplayResult;
    }

    @Override
    public ProcessReplayModel<Transition, XEventClass, Marking> copy() {
        return new AryaPetrinetReplayModel(this);
    }
}

