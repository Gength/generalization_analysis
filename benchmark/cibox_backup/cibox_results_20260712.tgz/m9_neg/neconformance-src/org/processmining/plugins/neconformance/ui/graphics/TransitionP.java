/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.models.graphbased.directed.AbstractDirectedGraph
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetEdge
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetNode
 *  org.processmining.models.graphbased.directed.petrinet.elements.ExpandableSubNet
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.shapes.Decorated
 */
package org.processmining.plugins.neconformance.ui.graphics;

import java.awt.Dimension;
import java.awt.Graphics2D;
import org.processmining.models.graphbased.directed.AbstractDirectedGraph;
import org.processmining.models.graphbased.directed.petrinet.PetrinetEdge;
import org.processmining.models.graphbased.directed.petrinet.PetrinetNode;
import org.processmining.models.graphbased.directed.petrinet.elements.ExpandableSubNet;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.shapes.Decorated;
import org.processmining.plugins.neconformance.ui.graphics.ITransitionPDecorator;
import org.processmining.plugins.neconformance.ui.graphics.PetrinetGraphP;

public class TransitionP
extends Transition
implements Decorated {
    protected ITransitionPDecorator decorator;

    public TransitionP(String label, AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>> net) {
        this(label, net, new Dimension(50, 35));
    }

    public TransitionP(String label, AbstractDirectedGraph<PetrinetNode, PetrinetEdge<? extends PetrinetNode, ? extends PetrinetNode>> net, Dimension dimension) {
        super(label, net);
        this.getAttributeMap().put("ProM_Vis_attr_showLabel", (Object)false);
        this.getAttributeMap().put("size", (Object)dimension);
    }

    public TransitionP(String label, PetrinetGraphP net, ExpandableSubNet parent) {
        this(label, net, parent, new Dimension(50, 35));
    }

    public TransitionP(String label, PetrinetGraphP net, ExpandableSubNet parent, Dimension dimension) {
        super(label, (AbstractDirectedGraph)net, parent);
        this.getAttributeMap().put("ProM_Vis_attr_showLabel", (Object)false);
        this.getAttributeMap().put("size", (Object)dimension);
    }

    public void decorate(Graphics2D g2d, double x, double y, double width, double height) {
        if (this.decorator != null) {
            this.decorator.decorate(g2d, x, y, width, height);
        }
    }

    public ITransitionPDecorator getDecorator() {
        return this.decorator;
    }

    public void setDecorator(ITransitionPDecorator decorator) {
        this.decorator = decorator;
    }
}

