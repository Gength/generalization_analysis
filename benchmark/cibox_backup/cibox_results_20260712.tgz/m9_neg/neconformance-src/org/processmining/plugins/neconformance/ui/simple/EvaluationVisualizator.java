/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.ui.simple;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import org.processmining.plugins.neconformance.plugins.simple.PetrinetEvaluatorResult;
import org.processmining.plugins.neconformance.ui.simple.AlignmentPane;
import org.processmining.plugins.neconformance.ui.simple.PetrinetPane;
import org.processmining.plugins.neconformance.ui.simple.TraceSelectorPane;

public class EvaluationVisualizator
extends JPanel {
    private static final long serialVersionUID = -4858007119206L;
    private AlignmentPane alignPane;
    private TraceSelectorPane tracePane;
    private PetrinetPane petriPane;
    private PetrinetEvaluatorResult result;

    public EvaluationVisualizator(PetrinetEvaluatorResult result) {
        this.result = result;
        this.alignPane = new AlignmentPane(this);
        this.tracePane = new TraceSelectorPane(this);
        this.petriPane = new PetrinetPane(this);
        this.setLayout(new BorderLayout());
        this.add((Component)this.alignPane, "South");
        JSplitPane split = new JSplitPane(1, this.tracePane, this.petriPane);
        this.add((Component)split, "Center");
    }

    public PetrinetEvaluatorResult getResult() {
        return this.result;
    }

    public void notifyTraceSelection(int selectedIndex) {
        if (selectedIndex <= 0) {
            this.petriPane.notifyGlobalView();
        } else {
            this.petriPane.notifyTraceSelection(selectedIndex - 1);
            this.alignPane.notifyTraceSelection(selectedIndex - 1);
        }
    }

    public void notifyReplayStepSelection(int selectedTraceIndex, int selectedReplayIndex) {
        if (selectedReplayIndex < 0) {
            return;
        }
        this.petriPane.notifyReplayStepSelection(selectedTraceIndex, selectedReplayIndex);
    }
}

