/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.classification.XEventClassifier
 *  org.deckfour.xes.info.impl.XLogInfoImpl
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 */
package org.processmining.plugins.neconformance.bags.naieve;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.info.impl.XLogInfoImpl;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.plugins.neconformance.bags.LogBag;

public class NaieveLogBag
implements LogBag {
    private XLog log;
    private XEventClassifier classifier;
    private int windowSize;
    List<XEventClass> eventClasses;
    Map<String, Set<BitSet>> bagsPerClass;

    public NaieveLogBag(XLog log) {
        this(log, XLogInfoImpl.STANDARD_CLASSIFIER, -1);
    }

    public NaieveLogBag(XLog log, XEventClassifier classifier) {
        this(log, classifier, -1);
    }

    public NaieveLogBag(XLog log, XEventClassifier classifier, int windowSize) {
        this.log = log;
        this.classifier = classifier;
        this.windowSize = windowSize;
        this.constructLookupTable();
    }

    private void constructLookupTable() {
        this.eventClasses = new ArrayList<XEventClass>(XEventClasses.deriveEventClasses((XEventClassifier)this.classifier, (XLog)this.log).getClasses());
        this.bagsPerClass = new HashMap<String, Set<BitSet>>();
        for (XEventClass ec : this.eventClasses) {
            this.bagsPerClass.put(ec.toString(), new HashSet());
        }
        int t = 0;
        while (t < this.log.size()) {
            XTrace trace = (XTrace)this.log.get(t);
            int startIndex = 0;
            while (startIndex < trace.size()) {
                String eventClassP = this.classifier.getClassIdentity((XEvent)trace.get(startIndex));
                BitSet eventBag = this.getEventBagBeforePosition(trace, startIndex);
                this.bagsPerClass.get(eventClassP).add(eventBag);
                ++startIndex;
            }
            ++t;
        }
    }

    @Override
    public int getLargestSharedBagSize(Set<String> window, String entryClass) {
        BitSet windowBag = this.getEventBag(window);
        int largestShared = -1;
        for (BitSet eventBag : this.bagsPerClass.get(entryClass)) {
            BitSet andWindowBag = (BitSet)windowBag.clone();
            andWindowBag.and(eventBag);
            int shared = andWindowBag.cardinality();
            if (shared > largestShared) {
                largestShared = shared;
            }
            if (largestShared != window.size()) continue;
            return largestShared;
        }
        return largestShared;
    }

    @Override
    public int getSmallestSharedSize(Set<String> window, String entryClass) {
        BitSet windowBag = this.getEventBag(window);
        int smallestShared = -1;
        for (BitSet eventBag : this.bagsPerClass.get(entryClass)) {
            BitSet andWindowBag = (BitSet)windowBag.clone();
            andWindowBag.and(eventBag);
            int shared = andWindowBag.cardinality();
            if (shared < smallestShared || smallestShared == -1) {
                smallestShared = shared;
            }
            if (smallestShared != 0) continue;
            return smallestShared;
        }
        return smallestShared;
    }

    private BitSet getEventBagBeforePosition(XTrace trace, int position) {
        HashSet<String> eventBag = new HashSet<String>();
        int startPos = position - this.windowSize;
        if (this.windowSize < 0 || startPos < 0) {
            startPos = 0;
        }
        int checkPos = position - 1;
        while (checkPos >= startPos) {
            String eventClassP = this.classifier.getClassIdentity((XEvent)trace.get(checkPos));
            eventBag.add(eventClassP);
            --checkPos;
        }
        return this.getEventBag(eventBag);
    }

    private BitSet getEventBag(Set<String> window) {
        BitSet bitBag = new BitSet(this.eventClasses.size());
        int i = 0;
        while (i < this.eventClasses.size()) {
            if (window.contains(this.eventClasses.get(i).toString())) {
                bitBag.set(i, true);
            }
            ++i;
        }
        return bitBag;
    }
}

