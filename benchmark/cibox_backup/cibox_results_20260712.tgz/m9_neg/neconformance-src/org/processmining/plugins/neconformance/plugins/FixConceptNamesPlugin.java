/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.classification.XEventClassifier
 *  org.deckfour.xes.extension.std.XConceptExtension
 *  org.deckfour.xes.factory.XFactory
 *  org.deckfour.xes.factory.XFactoryRegistry
 *  org.deckfour.xes.info.impl.XLogInfoImpl
 *  org.deckfour.xes.model.XAttributable
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.contexts.uitopia.UIPluginContext
 *  org.processmining.contexts.uitopia.annotations.UITopiaVariant
 *  org.processmining.framework.plugin.annotations.Plugin
 *  org.processmining.framework.plugin.annotations.PluginVariant
 *  org.processmining.plugins.kutoolbox.utils.LogUtils
 */
package org.processmining.plugins.neconformance.plugins;

import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.classification.XEventClassifier;
import org.deckfour.xes.extension.std.XConceptExtension;
import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.factory.XFactoryRegistry;
import org.deckfour.xes.info.impl.XLogInfoImpl;
import org.deckfour.xes.model.XAttributable;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.contexts.uitopia.UIPluginContext;
import org.processmining.contexts.uitopia.annotations.UITopiaVariant;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;
import org.processmining.plugins.kutoolbox.utils.LogUtils;

@Plugin(name="Fix Event Concept Names for Ukkonen Tree", parameterLabels={"Log"}, returnLabels={"Fixed Log"}, returnTypes={XLog.class}, userAccessible=true, help="Fix Event Concept Names for Ukkonen Tree")
public class FixConceptNamesPlugin {
    @UITopiaVariant(uiLabel="Fix Event Concept Names for Ukkonen Tree", affiliation="Eindhoven University of Technology", author="Seppe K.L.M. vanden Broucke", email="seppe.vandenbroucke@econ.kuleuven.be", website="http://econ.kuleuven.be")
    @PluginVariant(variantLabel="Wizard settings", requiredParameterLabels={0})
    public static XLog fixLog(UIPluginContext context, XLog log) {
        XEventClasses classes = XEventClasses.deriveEventClasses((XEventClassifier)XLogInfoImpl.NAME_CLASSIFIER, (XLog)log);
        XLog newLog = LogUtils.newLog((String)"Fixed Log");
        XFactory factory = (XFactory)XFactoryRegistry.instance().currentDefault();
        for (XTrace trace : log) {
            XTrace newTrace = factory.createTrace(trace.getAttributes());
            String traceAsString = "";
            int i = 0;
            while (i < trace.size()) {
                XEvent clonedEvent = (XEvent)((XEvent)trace.get(i)).clone();
                XEventClass oldName = classes.getClassOf(clonedEvent);
                String newName = String.valueOf(oldName.getIndex());
                XConceptExtension.instance().assignName((XAttributable)clonedEvent, newName);
                newTrace.add((Object)clonedEvent);
                context.log(String.valueOf(oldName.getId()) + " --> " + newName);
                traceAsString = String.valueOf(traceAsString) + "\"" + newName + "\", ";
                ++i;
            }
            System.out.println(traceAsString);
            newLog.add((Object)newTrace);
        }
        return newLog;
    }
}

