/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 */
package org.processmining.plugins.neconformance.types;

import org.deckfour.xes.classification.XEventClass;

public class WeightedEventClass {
    public final XEventClass eventClass;
    public final double weight;

    public WeightedEventClass(XEventClass eventClass, double weight) {
        this.eventClass = eventClass;
        this.weight = weight;
    }

    public int hashCode() {
        return this.eventClass.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (this.getClass() != obj.getClass()) {
            return false;
        }
        WeightedEventClass other = (WeightedEventClass)obj;
        return this.eventClass.equals((Object)other.eventClass);
    }

    public String toString() {
        return String.valueOf(this.eventClass.getId()) + " (" + this.weight + ")";
    }
}

