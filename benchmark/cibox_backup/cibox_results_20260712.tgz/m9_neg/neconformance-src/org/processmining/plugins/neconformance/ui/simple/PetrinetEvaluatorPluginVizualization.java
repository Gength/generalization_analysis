/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.contexts.uitopia.annotations.Visualizer
 *  org.processmining.framework.plugin.PluginContext
 *  org.processmining.framework.plugin.annotations.Plugin
 *  org.processmining.framework.plugin.annotations.PluginVariant
 */
package org.processmining.plugins.neconformance.ui.simple;

import javax.swing.JComponent;
import org.processmining.contexts.uitopia.annotations.Visualizer;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;
import org.processmining.plugins.neconformance.plugins.simple.PetrinetEvaluatorResult;
import org.processmining.plugins.neconformance.ui.simple.EvaluationVisualizator;

@Plugin(name="Visualize Petri Net Conformance Evaluation Result", parameterLabels={"Petri net Evaluation Result"}, returnLabels={"Visualization"}, returnTypes={JComponent.class})
@Visualizer
public class PetrinetEvaluatorPluginVizualization {
    @PluginVariant(requiredParameterLabels={0})
    public static JComponent visualize(PluginContext context, PetrinetEvaluatorResult result) {
        return new EvaluationVisualizator(result);
    }
}

