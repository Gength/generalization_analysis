/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.trees.ukkonen;

class SequenceTerminal<S> {
    private final S sequence;

    SequenceTerminal(S sequence) {
        this.sequence = sequence;
    }

    public boolean equals(Object o) {
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        return ((SequenceTerminal)o).sequence.equals(this.sequence);
    }

    public int hashCode() {
        return this.sequence.hashCode();
    }

    public String toString() {
        return "$" + this.sequence.toString() + "$";
    }

    public S getSequence() {
        return this.sequence;
    }
}

