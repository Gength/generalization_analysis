/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import org.processmining.plugins.neconformance.ui.EvaluationVisualizator;

public class InformationPane
extends JPanel {
    private static final long serialVersionUID = 7296759288208140407L;
    private JTextArea textarea;

    public InformationPane(EvaluationVisualizator evaluationVisualizator) {
        this.setLayout(new BorderLayout());
        this.textarea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(this.textarea);
        this.add((Component)scrollPane, "Center");
    }

    public void setText(String text) {
        this.textarea.setText(text);
    }
}

