/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.model.XLog
 */
package org.processmining.plugins.neconformance.metrics.impl;

import org.deckfour.xes.model.XLog;
import org.processmining.plugins.neconformance.metrics.impl.AbstractBehavioralPetrinetMetric;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;

public class BehavioralRecallMetric
extends AbstractBehavioralPetrinetMetric {
    public BehavioralRecallMetric(PetrinetReplayModel replayModel, AbstractNegativeEventInducer inducer, XLog log, boolean checkUnmapped, boolean useMultiTreadedCalculation) {
        super(replayModel, inducer, log, false, false, checkUnmapped, false, useMultiTreadedCalculation);
    }

    @Override
    protected double getCalculatedValue() {
        if (this.truePositives == 0.0 && this.falseNegatives == 0.0) {
            return 1.0;
        }
        return this.truePositives / (this.truePositives + this.falseNegatives);
    }
}

