/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XLog
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.groupedlog.GroupedXLog
 */
package org.processmining.plugins.neconformance.metrics.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.groupedlog.GroupedXLog;
import org.processmining.plugins.neconformance.metrics.AbstractConformanceMetric;
import org.processmining.plugins.neconformance.metrics.impl.ReplayTask;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.models.impl.PetrinetReplayModel;
import org.processmining.plugins.neconformance.models.impl.TraceReplayRunnable;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;
import org.processmining.plugins.neconformance.types.WeightedEventClass;

public abstract class AbstractBehavioralPetrinetMetric
extends AbstractConformanceMetric {
    protected double truePositives;
    protected double falsePositives;
    protected double trueNegatives;
    protected double falseNegatives;
    protected double allowedGeneralizations;
    protected double disallowedGeneralizations;
    protected boolean checkNegatives;
    protected boolean checkGeneralization;
    protected boolean checkUnmappedRecall;
    protected boolean checkUnmappedPrecision;
    protected boolean useMultiThreadedCalculation;
    protected AbstractNegativeEventInducer inducer;
    protected GroupedXLog groupedLog;

    public AbstractBehavioralPetrinetMetric(ProcessReplayModel<?, ?, ?> replayModel, AbstractNegativeEventInducer inducer, XLog log, boolean checkNegatives, boolean checkGeneralization, boolean checkUnmappedRecall, boolean checkUnmappedPrecision, boolean useMultiTreadedCalculation) {
        super(replayModel);
        this.groupedLog = new GroupedXLog(log);
        this.inducer = inducer;
        this.checkNegatives = checkNegatives;
        this.checkGeneralization = checkGeneralization;
        this.checkUnmappedRecall = checkUnmappedRecall;
        this.checkUnmappedPrecision = checkUnmappedPrecision;
        this.useMultiThreadedCalculation = useMultiTreadedCalculation;
    }

    public void reset() {
        this.truePositives = 0.0;
        this.falsePositives = 0.0;
        this.trueNegatives = 0.0;
        this.falseNegatives = 0.0;
        this.allowedGeneralizations = 0.0;
        this.disallowedGeneralizations = 0.0;
    }

    @Override
    public double getValue() {
        this.reset();
        ArrayBlockingQueue<Runnable> worksQueue = null;
        ThreadPoolExecutor executor = null;
        ArrayList<ReplayTask> taskList = new ArrayList<ReplayTask>();
        if (this.useMultiThreadedCalculation) {
            worksQueue = new ArrayBlockingQueue<Runnable>(10);
            executor = new ThreadPoolExecutor(10, 20, 1L, TimeUnit.MINUTES, worksQueue);
        }
        int t = 0;
        while (t < this.groupedLog.size()) {
            XTrace trace = (XTrace)this.groupedLog.get(t).get(0);
            int times = this.groupedLog.get(t).size();
            if (!this.useMultiThreadedCalculation) {
                this.evaluateTrace(trace, times);
            } else {
                List<XEventClass> classSequence = this.getTraceAsClassSequence(trace);
                ProcessReplayModel clonedModel = this.replayModel.copy();
                taskList.add(new ReplayTask(new TraceReplayRunnable<Transition, XEventClass, Marking>(clonedModel, classSequence), trace, times));
            }
            ++t;
        }
        if (this.useMultiThreadedCalculation) {
            int i = 0;
            while (i < taskList.size()) {
                while (executor.getQueue().remainingCapacity() == 0) {
                }
                executor.execute(((ReplayTask)taskList.get((int)i)).runnable);
                ++i;
            }
            executor.shutdown();
            try {
                while (!executor.awaitTermination(10L, TimeUnit.SECONDS)) {
                }
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            for (ReplayTask task : taskList) {
                this.evaluateTrace(task.runnable.getReplayModel(), task.trace, task.times);
            }
        }
        return this.getCalculatedValue();
    }

    protected abstract double getCalculatedValue();

    protected void evaluateTrace(XTrace trace, int times) {
        this.replayModel.reset();
        List<XEventClass> classSequence = this.getTraceAsClassSequence(trace);
        ((PetrinetReplayModel)this.replayModel).replay(classSequence);
        this.evaluateTrace(this.replayModel, trace, times);
    }

    protected void evaluateTrace(ProcessReplayModel<?, ?, ?> replayModel, XTrace trace, int times) {
        Set<Transition> orphanedModelElements = ((PetrinetReplayModel)this.replayModel).getOrphanedModelElements();
        int step = 0;
        while (step < replayModel.size()) {
            ProcessReplayModel.ReplayMove type = replayModel.getReplayMove(step);
            switch (type) {
                case BOTH_SYNCHRONOUS: {
                    this.truePositives += 1.0 * (double)times;
                    break;
                }
                case BOTH_FORCED: {
                    this.falseNegatives += 1.0 * (double)times;
                    break;
                }
                case LOGONLY_INSERTED: {
                    if (!this.checkUnmappedRecall) break;
                    this.falseNegatives += 1.0 * (double)times;
                    break;
                }
                case MODELONLY_SKIPPED: {
                    break;
                }
                case MODELONLY_UNOBSERVABLE: {
                    break;
                }
            }
            if (this.checkNegatives || this.checkGeneralization) {
                int currentPositionInTrace = this.getTracePositionForReplayStep(replayModel, step);
                int latestNonInvisibleStep = step - 1;
                while (latestNonInvisibleStep >= 0) {
                    if (!replayModel.getReplayMove(latestNonInvisibleStep).equals((Object)ProcessReplayModel.ReplayMove.MODELONLY_UNOBSERVABLE)) break;
                    --latestNonInvisibleStep;
                }
                if (type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS) || type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_FORCED)) {
                    Set modelExecutables;
                    Set executables = latestNonInvisibleStep < 0 ? ((PetrinetReplayModel)replayModel).getExecutableLogElements((Marking)replayModel.getInitialState()) : ((PetrinetReplayModel)replayModel).getExecutableLogElements((Marking)replayModel.getModelState(latestNonInvisibleStep));
                    Set set = modelExecutables = latestNonInvisibleStep < 0 ? ((PetrinetReplayModel)replayModel).getExecutableModelElements((Marking)replayModel.getInitialState()) : ((PetrinetReplayModel)replayModel).getExecutableModelElements((Marking)replayModel.getModelState(latestNonInvisibleStep));
                    if (this.checkNegatives) {
                        Set<WeightedEventClass> negativeevents = this.inducer.getNegativeEvents(trace, currentPositionInTrace);
                        for (WeightedEventClass ec : negativeevents) {
                            if (executables.contains(ec.eventClass)) {
                                this.falsePositives += ec.weight * (double)times;
                                continue;
                            }
                            this.trueNegatives += ec.weight * (double)times;
                        }
                        if (this.checkUnmappedPrecision) {
                            for (Transition tr : orphanedModelElements) {
                                if (!modelExecutables.contains(tr)) continue;
                                this.falsePositives += 1.0 * (double)times;
                            }
                        }
                    }
                    if (this.checkGeneralization) {
                        Set<WeightedEventClass> generalizedevents = this.inducer.getGeneralizedEvents(trace, currentPositionInTrace);
                        for (WeightedEventClass ec : generalizedevents) {
                            if (executables.contains(ec.eventClass)) {
                                this.allowedGeneralizations += ec.weight * (double)times;
                                continue;
                            }
                            this.disallowedGeneralizations += ec.weight * (double)times;
                        }
                    }
                }
            }
            ++step;
        }
    }

    private int getTracePositionForReplayStep(ProcessReplayModel<?, ?, ?> replayModel, int replayStep) {
        int positionInTrace = -1;
        int step = 0;
        while (step <= replayStep) {
            ProcessReplayModel.ReplayMove type = replayModel.getReplayMove(step);
            if (type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS) || type.equals((Object)ProcessReplayModel.ReplayMove.BOTH_FORCED) || type.equals((Object)ProcessReplayModel.ReplayMove.LOGONLY_INSERTED)) {
                ++positionInTrace;
            }
            ++step;
        }
        return positionInTrace;
    }

    private List<XEventClass> getTraceAsClassSequence(XTrace trace) {
        ArrayList<XEventClass> sequence = new ArrayList<XEventClass>();
        for (XEvent event : trace) {
            sequence.add(this.inducer.getClassAlphabet().getClassOf(event));
        }
        return sequence;
    }
}

