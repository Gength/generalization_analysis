/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 *  org.processmining.plugins.kutoolbox.utils.PetrinetUtils
 */
package org.processmining.plugins.neconformance.models.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.kutoolbox.utils.PetrinetUtils;
import org.processmining.plugins.neconformance.models.AbstractProcessReplayModel;
import org.processmining.plugins.neconformance.models.ProcessReplayModel;
import org.processmining.plugins.neconformance.utils.PetrinetReplayUtils;

public class PetrinetReplayModel
extends AbstractProcessReplayModel<Transition, XEventClass, Marking> {
    protected Petrinet net;
    protected Marking currentMarking;
    protected PetrinetLogMapper mapping;
    protected Random generator;
    protected List<Boolean> transitionIsForced;

    public PetrinetReplayModel(Petrinet net, Marking initialMarking, PetrinetLogMapper mapping) {
        super(mapping.getTransitions(), mapping.getEventClasses(), PetrinetUtils.getInitialMarking((Petrinet)net, (Marking)initialMarking));
        this.net = net;
        this.mapping = mapping;
    }

    public PetrinetReplayModel(PetrinetReplayModel toClone) {
        this(toClone.getPetrinet(), (Marking)toClone.getInitialState(), toClone.getMapping());
    }

    @Override
    public void reset() {
        super.reset();
        this.currentMarking = new Marking((Collection)this.initialState);
        this.transitionIsForced = new ArrayList<Boolean>();
        this.generator = new Random();
    }

    @Override
    public void replay(List<XEventClass> trace) {
        this.reset();
        int currentSequencePosition = 0;
        while (currentSequencePosition < trace.size()) {
            XEventClass currentClass = trace.get(currentSequencePosition);
            HashSet<Transition> enabledCandidates = new HashSet();
            HashSet<Transition> allCandidates = new HashSet();
            Set<Object> filteredEnabledCandidates = new HashSet();
            Set<Object> filteredForcedCandidates = new HashSet();
            XEventClass nextClass = currentSequencePosition < trace.size() - 1 ? trace.get(currentSequencePosition + 1) : null;
            enabledCandidates = PetrinetReplayUtils.getEnabledMappedTransitions(this.net, this.currentMarking, this.mapping, currentClass);
            allCandidates = PetrinetReplayUtils.getMappedTransitions(this.mapping, currentClass);
            filteredEnabledCandidates = this.filterOnNextTaskEnabler(enabledCandidates, currentClass, nextClass);
            filteredForcedCandidates = this.filterOnNextTaskEnabler(allCandidates, currentClass, nextClass);
            List<Transition> invisiblePath = PetrinetReplayUtils.getInvisibleTaskReachabilityPaths(this.net, this.mapping, currentClass, this.currentMarking);
            ProcessReplayModel.ReplayMove move = null;
            Transition t = null;
            XEventClass c = null;
            boolean f = false;
            if (enabledCandidates.size() > 0) {
                t = filteredEnabledCandidates.size() > 0 ? this.getRandomTransition(filteredEnabledCandidates) : this.getRandomTransition(enabledCandidates);
                c = currentClass;
                move = ProcessReplayModel.ReplayMove.BOTH_SYNCHRONOUS;
            } else if (invisiblePath != null) {
                int i = 0;
                while (i < invisiblePath.size() - 1) {
                    Marking invm = this.currentMarking;
                    invm = PetrinetReplayUtils.getMarkingAfterFire(this.net, invm, invisiblePath.get(i));
                    this.addReplayStep(ProcessReplayModel.ReplayMove.MODELONLY_UNOBSERVABLE, invisiblePath.get(i), null, invm);
                    this.transitionIsForced.add(false);
                    this.currentMarking = invm;
                    ++i;
                }
                t = invisiblePath.get(invisiblePath.size() - 1);
                c = null;
                move = ProcessReplayModel.ReplayMove.MODELONLY_UNOBSERVABLE;
            } else if (allCandidates.size() > 0) {
                t = filteredForcedCandidates.size() > 0 ? this.getRandomTransition(filteredForcedCandidates) : this.getRandomTransition(allCandidates);
                c = currentClass;
                move = ProcessReplayModel.ReplayMove.BOTH_FORCED;
                f = true;
            } else {
                t = null;
                c = currentClass;
                move = ProcessReplayModel.ReplayMove.LOGONLY_INSERTED;
            }
            Marking m = this.currentMarking;
            if (t != null) {
                m = PetrinetReplayUtils.getMarkingAfterFire(this.net, m, t);
            }
            if (c != null) {
                ++currentSequencePosition;
            }
            this.addReplayStep(move, t, c, m);
            this.transitionIsForced.add(f);
            this.currentMarking = m;
        }
    }

    private Transition getRandomTransition(Set<Transition> choices) {
        int index = this.generator.nextInt(choices.size());
        return (Transition)choices.toArray()[index];
    }

    public PetrinetLogMapper getMapping() {
        return this.mapping;
    }

    public Petrinet getPetrinet() {
        return this.net;
    }

    private Set<Transition> filterOnNextTaskEnabler(Set<Transition> fireCandidates, XEventClass currentClass, XEventClass nextClass) {
        HashSet<Transition> filtered = new HashSet<Transition>();
        for (Transition t : fireCandidates) {
            Set<Transition> nextTaskEnabledTransitions = null;
            Marking nextState = PetrinetReplayUtils.getMarkingAfterFire(this.net, this.currentMarking, t);
            if (PetrinetReplayUtils.isInvisibleTransition(t, this.mapping)) {
                nextTaskEnabledTransitions = PetrinetReplayUtils.getEnabledMappedTransitions(this.net, nextState, this.mapping, currentClass);
            } else if (nextClass != null && !PetrinetReplayUtils.isInvisibleTransition(t, this.mapping)) {
                nextTaskEnabledTransitions = PetrinetReplayUtils.getEnabledMappedTransitions(this.net, nextState, this.mapping, nextClass);
            }
            if (nextTaskEnabledTransitions != null && nextTaskEnabledTransitions.size() <= 0) continue;
            filtered.add(t);
        }
        return filtered;
    }

    @Override
    public boolean isExecutableModelElement(Transition element, Marking state) {
        return PetrinetReplayUtils.getEnabledTransitions(this.net, state).contains(element);
    }

    @Override
    public boolean isExecutableLogElement(XEventClass element, Marking state) {
        return PetrinetReplayUtils.isTaskReachableByInvisiblePaths(this.net, this.mapping, element, state);
    }

    @Override
    public Set<Transition> getOrphanedModelElements() {
        HashSet<Transition> orphans = new HashSet<Transition>();
        for (Transition tr : this.mapping.getTransitions()) {
            if (this.mapping.transitionIsInvisible(tr) || this.mapping.transitionHasEvent(tr)) continue;
            orphans.add(tr);
        }
        return orphans;
    }

    @Override
    public Set<XEventClass> getOrphanedLogElements() {
        HashSet<XEventClass> orphans = new HashSet<XEventClass>();
        for (XEventClass ec : this.mapping.getEventClasses()) {
            if (this.mapping.eventHasTransition(ec)) continue;
            orphans.add(ec);
        }
        return orphans;
    }

    @Override
    public ProcessReplayModel<Transition, XEventClass, Marking> copy() {
        return new PetrinetReplayModel(this);
    }
}

