/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.bags;

import java.util.Set;

public interface LogBag {
    public int getLargestSharedBagSize(Set<String> var1, String var2);

    public int getSmallestSharedSize(Set<String> var1, String var2);
}

