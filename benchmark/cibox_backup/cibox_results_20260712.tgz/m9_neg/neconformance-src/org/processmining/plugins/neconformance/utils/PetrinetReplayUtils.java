/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.processmining.models.graphbased.directed.DirectedGraphNode
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.graphbased.directed.petrinet.PetrinetEdge
 *  org.processmining.models.graphbased.directed.petrinet.elements.Arc
 *  org.processmining.models.graphbased.directed.petrinet.elements.Place
 *  org.processmining.models.graphbased.directed.petrinet.elements.Transition
 *  org.processmining.models.semantics.IllegalTransitionException
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.models.semantics.petrinet.PetrinetSemantics
 *  org.processmining.models.semantics.petrinet.impl.PetrinetSemanticsFactory
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 *  org.processmining.plugins.kutoolbox.utils.PetrinetUtils
 */
package org.processmining.plugins.neconformance.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.processmining.models.graphbased.directed.DirectedGraphNode;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.PetrinetEdge;
import org.processmining.models.graphbased.directed.petrinet.elements.Arc;
import org.processmining.models.graphbased.directed.petrinet.elements.Place;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.IllegalTransitionException;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.models.semantics.petrinet.PetrinetSemantics;
import org.processmining.models.semantics.petrinet.impl.PetrinetSemanticsFactory;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.kutoolbox.utils.PetrinetUtils;

public class PetrinetReplayUtils
extends PetrinetUtils {
    public static boolean isInvisibleTransition(Transition t, PetrinetLogMapper m) {
        return PetrinetReplayUtils.isInvisibleTransition((Transition)t) || m.transitionIsInvisible(t);
    }

    public static void setInvisibleTransitions(Petrinet petriNet, PetrinetLogMapper m) {
        for (Transition t : petriNet.getTransitions()) {
            t.setInvisible(PetrinetReplayUtils.isInvisibleTransition(t, m));
        }
    }

    public static Marking getMarkingAfterFire(Petrinet net, Marking current, Transition fired) {
        PetrinetSemantics semantics = PetrinetSemanticsFactory.regularPetrinetSemantics(Petrinet.class);
        semantics.initialize(net.getTransitions(), (Object)current);
        Marking requiredMarking = new Marking();
        HashSet<Place> beforePlaces = new HashSet<Place>();
        Collection aInEdges = net.getInEdges((DirectedGraphNode)fired);
        for (PetrinetEdge inEdge : aInEdges) {
            Place before = (Place)inEdge.getSource();
            beforePlaces.add(before);
            int weight = ((Arc)inEdge).getWeight();
            requiredMarking.add((Object)before, Integer.valueOf(weight));
        }
        Marking forcedMarking = new Marking((Collection)current);
        for (Place p : beforePlaces) {
            int missing = requiredMarking.occurrences((Object)p) - forcedMarking.occurrences((Object)p);
            if (missing <= 0) continue;
            forcedMarking.add((Object)p, Integer.valueOf(missing));
        }
        semantics.setCurrentState((Object)forcedMarking);
        try {
            semantics.executeExecutableTransition((Object)fired);
        }
        catch (IllegalTransitionException e) {
            System.err.println("DANGER! Illegal transition exception occurred when trying to derive next state!");
            System.err.println("Current marking is:");
            System.err.println(current);
            System.err.println("All before places are:");
            System.err.println(beforePlaces);
            System.err.println("Required marking is:");
            System.err.println(requiredMarking);
            System.err.println("Constructed marking is:");
            System.err.println(forcedMarking);
            System.err.println("Transition was:");
            System.err.println(fired);
            System.err.println("I'm putting the output places in the current marking...");
            Marking newMarking = current;
            newMarking.addAll((Collection)PetrinetReplayUtils.getPlacesAfterTransition((Petrinet)net, (Transition)fired));
            return newMarking;
        }
        Marking newMarking = (Marking)semantics.getCurrentState();
        return newMarking;
    }

    public static Set<Transition> getEnabledTransitions(Petrinet net, Marking current) {
        PetrinetSemantics semantics = PetrinetSemanticsFactory.regularPetrinetSemantics(Petrinet.class);
        semantics.initialize(net.getTransitions(), (Object)current);
        HashSet<Transition> fireables = new HashSet<Transition>(semantics.getExecutableTransitions());
        return fireables;
    }

    public static Set<Transition> getMappedTransitions(PetrinetLogMapper mapping, XEventClass task) {
        return new HashSet<Transition>(mapping.getTransitionsForActivity(task.toString()));
    }

    public static Set<Transition> getEnabledMappedTransitions(Petrinet net, Marking current, PetrinetLogMapper mapping, XEventClass task) {
        Set<Transition> allTransitions = PetrinetReplayUtils.getMappedTransitions(mapping, task);
        allTransitions.retainAll(PetrinetReplayUtils.getEnabledTransitions(net, current));
        return new HashSet<Transition>(allTransitions);
    }

    public static Set<Transition> getEnabledInvisibleTransitions(Petrinet net, Marking current, PetrinetLogMapper mapping) {
        Set<Transition> enabled = PetrinetReplayUtils.getEnabledTransitions(net, current);
        HashSet<Transition> invisibles = new HashSet<Transition>();
        for (Transition t : enabled) {
            if (!PetrinetReplayUtils.isInvisibleTransition(t, mapping)) continue;
            invisibles.add(t);
        }
        return invisibles;
    }

    public static Set<Transition> getInvisibleTransitions(Petrinet net, PetrinetLogMapper mapping) {
        HashSet<Transition> invisibles = new HashSet<Transition>();
        for (Transition t : net.getTransitions()) {
            if (!PetrinetReplayUtils.isInvisibleTransition(t, mapping)) continue;
            invisibles.add(t);
        }
        return invisibles;
    }

    public static Set<Transition> getVisibleTransitions(Petrinet net, PetrinetLogMapper mapping) {
        HashSet<Transition> visibles = new HashSet<Transition>();
        for (Transition t : net.getTransitions()) {
            if (PetrinetReplayUtils.isInvisibleTransition(t, mapping)) continue;
            visibles.add(t);
        }
        return visibles;
    }

    public static List<Transition> getInvisibleTaskReachabilityPaths(Petrinet petriNet, PetrinetLogMapper mapping, XEventClass task, Marking marking) {
        Marking initialMarking = PetrinetReplayUtils.getInitialMarking((Petrinet)petriNet, (Marking)marking);
        return PetrinetReplayUtils.getInvisibleTaskReachabilityPaths(petriNet, mapping, task, initialMarking, 50, true, true, false);
    }

    public static List<Transition> getInvisibleTaskReachabilityPaths(Petrinet petriNet, PetrinetLogMapper mapping, XEventClass task, Marking marking, int maxStates, boolean useImmediate, boolean useOne, boolean useBFS) {
        if (useImmediate && PetrinetReplayUtils.getEnabledMappedTransitions(petriNet, marking, mapping, task).size() > 0) {
            return new ArrayList<Transition>();
        }
        List<Transition> single = PetrinetReplayUtils.getSingleInvisibleTaskReachabilityPath(petriNet, mapping, task, marking);
        if (useOne && single != null) {
            return single;
        }
        return PetrinetReplayUtils.getInvisibleTaskReachabilityPath(petriNet, mapping, task, marking, maxStates, useBFS);
    }

    public static List<Transition> getInvisibleTaskReachabilityPath(Petrinet petriNet, PetrinetLogMapper mapping, XEventClass task, Marking marking, int maxStates, boolean useBFS) {
        HashSet<Marking> visitedMarkings = new HashSet<Marking>();
        visitedMarkings.add(marking);
        ArrayList<Marking> queuedMarkings = new ArrayList<Marking>();
        queuedMarkings.add(marking);
        HashMap pathToMarking = new HashMap();
        pathToMarking.put(marking, new ArrayList());
        int statesChecked = 0;
        while (queuedMarkings.size() > 0) {
            if (maxStates > 0 && ++statesChecked > maxStates) {
                return null;
            }
            Marking markingTodo = (Marking)queuedMarkings.remove(0);
            if (PetrinetReplayUtils.getEnabledMappedTransitions(petriNet, markingTodo, mapping, task).size() > 0) {
                return (List)pathToMarking.get(markingTodo);
            }
            Set<Transition> fireableTransitions = PetrinetReplayUtils.getEnabledInvisibleTransitions(petriNet, markingTodo, mapping);
            for (Transition fire : fireableTransitions) {
                Marking after = PetrinetReplayUtils.getMarkingAfterFire(petriNet, markingTodo, fire);
                if (visitedMarkings.contains(after)) continue;
                if (useBFS) {
                    queuedMarkings.add(after);
                } else {
                    queuedMarkings.add(0, after);
                }
                ArrayList<Transition> newPath = new ArrayList<Transition>((Collection)pathToMarking.get(markingTodo));
                newPath.add(fire);
                pathToMarking.put(after, newPath);
                visitedMarkings.add(after);
            }
        }
        return null;
    }

    public static List<Transition> getSingleInvisibleTaskReachabilityPath(Petrinet petriNet, PetrinetLogMapper mapping, XEventClass task, Marking marking) {
        ArrayList<Transition> path = new ArrayList<Transition>();
        Set<Transition> fireableTransitions = PetrinetReplayUtils.getEnabledInvisibleTransitions(petriNet, marking, mapping);
        for (Transition fire : fireableTransitions) {
            Marking after = PetrinetReplayUtils.getMarkingAfterFire(petriNet, marking, fire);
            if (PetrinetReplayUtils.getEnabledMappedTransitions(petriNet, after, mapping, task).size() <= 0) continue;
            path.add(fire);
            return path;
        }
        return null;
    }

    public static boolean isTaskReachableByInvisiblePaths(Petrinet net, PetrinetLogMapper mapping, XEventClass element, Marking state) {
        return PetrinetReplayUtils.getInvisibleTaskReachabilityPaths(net, mapping, element, state) != null;
    }
}

