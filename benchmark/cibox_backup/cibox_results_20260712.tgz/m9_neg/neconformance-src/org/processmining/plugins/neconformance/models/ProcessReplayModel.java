/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.models;

import java.util.List;
import java.util.Set;

public interface ProcessReplayModel<M, L, S> {
    public M getModelElement(int var1);

    public L getTraceElement(int var1);

    public S getInitialState();

    public S getModelState(int var1);

    public Set<M> getExecutableModelElements(S var1);

    public Set<L> getExecutableLogElements(S var1);

    public Set<M> getOrphanedModelElements();

    public Set<L> getOrphanedLogElements();

    public boolean isExecutableModelElement(M var1, S var2);

    public boolean isExecutableLogElement(L var1, S var2);

    public void addReplayStep(ReplayMove var1, M var2, L var3, S var4);

    public int size();

    public void reset();

    public void replay(List<L> var1);

    public ReplayMove getReplayMove(int var1);

    public ProcessReplayModel<M, L, S> copy();

    public static enum ReplayMove {
        BOTH_SYNCHRONOUS,
        BOTH_FORCED,
        MODELONLY_UNOBSERVABLE,
        MODELONLY_SKIPPED,
        LOGONLY_INSERTED;

    }
}

