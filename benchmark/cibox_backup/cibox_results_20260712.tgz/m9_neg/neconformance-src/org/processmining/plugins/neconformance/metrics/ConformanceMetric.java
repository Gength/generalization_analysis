/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.metrics;

public interface ConformanceMetric {
    public double getValue();
}

