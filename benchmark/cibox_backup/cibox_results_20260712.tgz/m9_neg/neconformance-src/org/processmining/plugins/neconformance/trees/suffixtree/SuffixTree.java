/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  edu.uci.ics.jung.graph.DelegateTree
 */
package org.processmining.plugins.neconformance.trees.suffixtree;

import edu.uci.ics.jung.graph.DelegateTree;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import org.processmining.plugins.neconformance.trees.suffixtree.SuffixTreeEdge;
import org.processmining.plugins.neconformance.trees.suffixtree.SuffixTreeNode;

public class SuffixTree {
    private DelegateTree<SuffixTreeNode, SuffixTreeEdge> tree = new DelegateTree();

    public SuffixTree() {
        SuffixTreeNode ROOT_NODE = new SuffixTreeNode(-1);
        this.tree.addVertex((Object)ROOT_NODE);
    }

    public SuffixTreeNode addNode(SuffixTreeNode from, int stateCounter, String transitionName) {
        SuffixTreeNode node = new SuffixTreeNode(stateCounter);
        SuffixTreeEdge edge = new SuffixTreeEdge(from, node, transitionName);
        if (!this.tree.containsVertex((Object)node)) {
            this.tree.addChild((Object)edge, (Object)from, (Object)node);
            from.addEdge(transitionName, node);
        }
        return node;
    }

    public SuffixTreeNode getNodeOut(SuffixTreeNode from, String transitionName) {
        Collection<SuffixTreeNode> n = this.getNodesOut(from, transitionName);
        if (n == null || n.size() == 0) {
            return null;
        }
        return n.iterator().next();
    }

    public Collection<SuffixTreeNode> getNodesOut(SuffixTreeNode from, String transitionName) {
        Set<SuffixTreeNode> n = from.getNodesOut(transitionName);
        if (n == null) {
            return new HashSet<SuffixTreeNode>();
        }
        return n;
    }

    public int nrNodesOut(SuffixTreeNode from) {
        return from.nrNodesOut();
    }

    public SuffixTreeEdge getEdge(SuffixTreeNode from, SuffixTreeNode to) {
        return (SuffixTreeEdge)this.tree.findEdge((Object)from, (Object)to);
    }

    public Collection<SuffixTreeEdge> getInEdges(SuffixTreeNode to) {
        return this.tree.getInEdges((Object)to);
    }

    public Collection<SuffixTreeEdge> getOutEdges(SuffixTreeNode from) {
        return this.tree.getOutEdges((Object)from);
    }

    public SuffixTreeNode getRootNode() {
        return (SuffixTreeNode)this.tree.getRoot();
    }

    public DelegateTree<SuffixTreeNode, SuffixTreeEdge> getTree() {
        return this.tree;
    }
}

