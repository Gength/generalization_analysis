/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.processmining.plugins.kutoolbox.ui.FancyIntegerSlider
 *  org.processmining.plugins.kutoolbox.ui.TwoColumnParameterPanel
 *  org.processmining.plugins.kutoolbox.ui.UIAttributeConfigurator
 */
package org.processmining.plugins.neconformance.ui.wizard;

import java.util.HashMap;
import java.util.Map;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import org.processmining.plugins.kutoolbox.ui.FancyIntegerSlider;
import org.processmining.plugins.kutoolbox.ui.TwoColumnParameterPanel;
import org.processmining.plugins.kutoolbox.ui.UIAttributeConfigurator;

public class WizardSettingsPanel
extends TwoColumnParameterPanel
implements UIAttributeConfigurator {
    private static final long serialVersionUID = -2878063135102398114L;
    private int replayer;
    private boolean useBagInducer;
    private boolean useWeighted;
    private boolean useBothRatios;
    private boolean useCutOff;
    private int negWindow;
    private int genWindow;
    private boolean unmappedRecall;
    private boolean unmappedPrecision;
    private boolean unmappedGeneralization;
    private boolean useMultithreaded;
    private JRadioButton checkHeur;
    private JRadioButton checkHeRe;
    private JRadioButton checkArya;
    private JCheckBox checkBag;
    private JCheckBox checkWeighted;
    private JCheckBox checkRatio;
    private JCheckBox checkCut;
    private JCheckBox checkRecall;
    private JCheckBox checkPrecision;
    private JCheckBox checkGeneralization;
    private JCheckBox checkMt;
    private FancyIntegerSlider sliderNeg;
    private FancyIntegerSlider sliderGen;

    public WizardSettingsPanel() {
        super(75);
        this.init();
    }

    protected void init() {
        this.resetSettings();
        this.addDoubleLabel("Replay settings", 1);
        ButtonGroup group = this.addButtongroup();
        this.checkHeur = this.addRadiobutton("Use heuristic replayer", this.replayer == 0, 2, false);
        this.checkArya = this.addRadiobutton("Use alignment based replayer", this.replayer == 1, 3, false);
        this.checkHeRe = this.addRadiobutton("Use heuristic replayer with recovery", this.replayer == 2, 4, false);
        group.add(this.checkHeur);
        group.add(this.checkArya);
        group.add(this.checkHeRe);
        this.addDoubleLabel("Evaluation settings", 5);
        this.checkRecall = this.addCheckbox("Punish recall on unmapped log elements", this.unmappedRecall, 6, true);
        this.checkPrecision = this.addCheckbox("Punish precision on unmapped model elements", this.unmappedPrecision, 7, true);
        this.checkGeneralization = this.addCheckbox("Punish generalization on unmapped log elements", this.unmappedGeneralization, 58, true);
        this.checkGeneralization.setVisible(false);
        this.addDoubleLabel("Inducer settings", 10);
        this.checkBag = this.addCheckbox("Use bag-of-activity based inducer", this.useBagInducer, 11, false);
        this.checkWeighted = this.addCheckbox("Use weighted negative events", this.useWeighted, 12, false);
        this.checkRatio = this.addCheckbox("Use longest/shortest window instead of '1 minus'", this.useBothRatios, 13, false);
        this.checkCut = this.addCheckbox("Cut off window at next event occurrence", this.useCutOff, 14, false);
        this.sliderNeg = this.addIntegerSlider(-1, this.negWindow, 10, 15);
        this.sliderGen = this.addIntegerSlider(-1, this.genWindow, 10, 16);
        this.checkMt = this.addCheckbox("Use multithreaded calculation", this.useMultithreaded, 17, false);
    }

    public String getTitle() {
        return "Conformance Checking Settings";
    }

    public void resetSettings() {
        this.replayer = 0;
        this.useBagInducer = false;
        this.useWeighted = true;
        this.useBothRatios = false;
        this.useCutOff = false;
        this.unmappedRecall = true;
        this.unmappedPrecision = true;
        this.unmappedGeneralization = true;
        this.useMultithreaded = false;
        this.negWindow = -1;
        this.genWindow = -1;
    }

    public void setSettings(Map<String, Object> settings) {
        this.replayer = Integer.parseInt(settings.get("replayer").toString());
        this.useBagInducer = settings.get("useBagInducer").toString().equals("1");
        this.useWeighted = settings.get("useWeighted").toString().equals("1");
        this.useBothRatios = settings.get("useBothRatios").toString().equals("1");
        this.useCutOff = settings.get("useCutOff").toString().equals("1");
        this.negWindow = Integer.parseInt(settings.get("negWindow").toString());
        this.genWindow = Integer.parseInt(settings.get("genWindow").toString());
        this.unmappedRecall = settings.get("unmappedRecall").toString().equals("1");
        this.unmappedPrecision = settings.get("unmappedPrecision").toString().equals("1");
        this.unmappedGeneralization = settings.get("unmappedGeneralization").toString().equals("1");
        this.useMultithreaded = settings.get("useMultithreaded").toString().equals("1");
        this.checkHeur.setSelected(this.replayer == 0);
        this.checkArya.setSelected(this.replayer == 1);
        this.checkHeRe.setSelected(this.replayer == 2);
        this.checkBag.setSelected(this.useBagInducer);
        this.checkWeighted.setSelected(this.useWeighted);
        this.checkRatio.setSelected(this.useBothRatios);
        this.checkCut.setSelected(this.useCutOff);
        this.checkRecall.setSelected(this.unmappedRecall);
        this.checkPrecision.setSelected(this.unmappedPrecision);
        this.checkGeneralization.setSelected(this.unmappedGeneralization);
        this.checkMt.setSelected(this.useMultithreaded);
        this.sliderNeg.setValue(this.negWindow);
        this.sliderGen.setValue(this.genWindow);
    }

    public Map<String, Object> getSettings() {
        if (this.checkHeur.isSelected()) {
            this.replayer = 0;
        }
        if (this.checkArya.isSelected()) {
            this.replayer = 1;
        }
        if (this.checkHeRe.isSelected()) {
            this.replayer = 2;
        }
        this.useBagInducer = this.checkBag.isSelected();
        this.useWeighted = this.checkWeighted.isSelected();
        this.useBothRatios = this.checkRatio.isSelected();
        this.useCutOff = this.checkCut.isSelected();
        this.negWindow = this.sliderNeg.getValue() == 0 ? -1 : this.sliderNeg.getValue();
        this.genWindow = this.sliderGen.getValue() == 0 ? -1 : this.sliderGen.getValue();
        this.unmappedRecall = this.checkRecall.isSelected();
        this.unmappedPrecision = this.checkPrecision.isSelected();
        this.unmappedGeneralization = this.checkGeneralization.isSelected();
        this.useMultithreaded = this.checkMt.isSelected();
        HashMap<String, Object> settings = new HashMap<String, Object>();
        settings.put("replayer", "" + this.replayer);
        settings.put("useBagInducer", this.useBagInducer ? "1" : "0");
        settings.put("useWeighted", this.useWeighted ? "1" : "0");
        settings.put("useBothRatios", this.useBothRatios ? "1" : "0");
        settings.put("useCutOff", this.useCutOff ? "1" : "0");
        settings.put("unmappedRecall", this.unmappedRecall ? "1" : "0");
        settings.put("unmappedPrecision", this.unmappedPrecision ? "1" : "0");
        settings.put("unmappedGeneralization", this.unmappedGeneralization ? "1" : "0");
        settings.put("useMultithreaded", this.useMultithreaded ? "1" : "0");
        settings.put("negWindow", "" + this.negWindow);
        settings.put("genWindow", "" + this.genWindow);
        return settings;
    }

    protected void updateFields() {
    }
}

