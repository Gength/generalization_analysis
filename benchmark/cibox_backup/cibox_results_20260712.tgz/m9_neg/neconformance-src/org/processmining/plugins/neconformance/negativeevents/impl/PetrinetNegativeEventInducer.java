/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.deckfour.xes.classification.XEventClass
 *  org.deckfour.xes.classification.XEventClasses
 *  org.deckfour.xes.model.XEvent
 *  org.deckfour.xes.model.XTrace
 *  org.processmining.models.graphbased.directed.petrinet.Petrinet
 *  org.processmining.models.semantics.petrinet.Marking
 *  org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper
 *  org.processmining.plugins.kutoolbox.utils.PetrinetUtils
 *  org.processmining.plugins.yapetrinetreplayer.replayers.CompleteTraceReplayer
 */
package org.processmining.plugins.neconformance.negativeevents.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.deckfour.xes.classification.XEventClass;
import org.deckfour.xes.classification.XEventClasses;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XTrace;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.plugins.kutoolbox.logmappers.PetrinetLogMapper;
import org.processmining.plugins.kutoolbox.utils.PetrinetUtils;
import org.processmining.plugins.neconformance.negativeevents.AbstractNegativeEventInducer;
import org.processmining.plugins.neconformance.types.WeightedEventClass;
import org.processmining.plugins.yapetrinetreplayer.replayers.CompleteTraceReplayer;

public class PetrinetNegativeEventInducer
extends AbstractNegativeEventInducer {
    private Petrinet petriNet;
    private Marking marking;
    private PetrinetLogMapper mapper;
    private boolean returnZeroEvents = false;
    private CompleteTraceReplayer replayer;

    public PetrinetNegativeEventInducer(XEventClasses classes, Set<XEventClass> startingClasses, Petrinet petriNet, Marking marking, PetrinetLogMapper mapper) {
        super(classes, startingClasses);
        this.petriNet = petriNet;
        this.marking = marking;
        this.mapper = mapper;
        try {
            this.replayer = new CompleteTraceReplayer(petriNet, mapper);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Set<WeightedEventClass> getNegativeEvents(XTrace trace, int position, boolean isGeneralization) {
        String positiveClass = this.getEventClassAtPosition(trace, position);
        HashSet<WeightedEventClass> eventSet = new HashSet<WeightedEventClass>();
        for (XEventClass ec : this.classAlphabet.getClasses()) {
            double weight;
            if (ec.getId().equals(positiveClass)) continue;
            boolean isEnabled = this.isFittingTrace(trace, position, ec);
            if (isGeneralization) {
                weight = isEnabled ? 1.0 : 0.0;
            } else {
                double d = weight = isEnabled ? 0.0 : 1.0;
            }
            if (!(weight > 0.0) && !this.returnZeroEvents) continue;
            eventSet.add(new WeightedEventClass(ec, weight));
        }
        return eventSet;
    }

    public boolean isFittingTrace(XTrace trace, int position, XEventClass suffix) {
        ArrayList<XEvent> history = new ArrayList<XEvent>();
        int q = 0;
        while (q < position) {
            history.add((XEvent)((XEvent)trace.get(q)).clone());
            ++q;
        }
        history.add(this.mapper.makeEvent(suffix.getId()));
        Marking initialMarking = PetrinetUtils.getInitialMarking((Petrinet)this.petriNet, (Marking)this.marking);
        Set statePaths = this.replayer.getAllStatePathsForSequence(history, initialMarking, false, false, false, false, -1, false, true, 2);
        return statePaths != null && statePaths.size() != 0;
    }

    @Override
    public Set<WeightedEventClass> getNegativeEvents(XTrace trace, int position) {
        return this.getNegativeEvents(trace, position, false);
    }

    @Override
    public Set<WeightedEventClass> getGeneralizedEvents(XTrace trace, int position) {
        return this.getNegativeEvents(trace, position, true);
    }

    public Petrinet getPetriNet() {
        return this.petriNet;
    }

    public void setPetriNet(Petrinet petriNet) {
        this.petriNet = petriNet;
    }

    public PetrinetLogMapper getMapper() {
        return this.mapper;
    }

    public void setMapper(PetrinetLogMapper mapper) {
        this.mapper = mapper;
    }

    public boolean isReturnZeroEvents() {
        return this.returnZeroEvents;
    }

    public void setReturnZeroEvents(boolean returnZeroEvents) {
        this.returnZeroEvents = returnZeroEvents;
    }
}

