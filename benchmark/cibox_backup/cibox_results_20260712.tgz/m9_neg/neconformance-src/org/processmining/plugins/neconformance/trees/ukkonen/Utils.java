/*
 * Decompiled with CFR 0.152.
 */
package org.processmining.plugins.neconformance.trees.ukkonen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import org.processmining.plugins.neconformance.trees.ukkonen.Edge;
import org.processmining.plugins.neconformance.trees.ukkonen.Node;
import org.processmining.plugins.neconformance.trees.ukkonen.SequenceTerminal;
import org.processmining.plugins.neconformance.trees.ukkonen.SuffixTree;

public class Utils {
    static <I, S extends Iterable<I>> Object[] addTerminalToSequence(S sequence, SequenceTerminal<S> terminatingObject) {
        ArrayList<I> list = new ArrayList<I>();
        for (I item : sequence) {
            list.add(item);
        }
        Object[] newSequence = new Object[list.size() + 1];
        int i = 0;
        while (i < list.size()) {
            newSequence[i] = list.get(i);
            ++i;
        }
        newSequence[i] = terminatingObject;
        return newSequence;
    }

    static <T, S extends Iterable<T>> String printTreeForGraphViz(SuffixTree<T, S> tree) {
        return Utils.printTreeForGraphViz(tree, true);
    }

    static <T, S extends Iterable<T>> String printTreeForGraphViz(SuffixTree<T, S> tree, boolean printSuffixLinks) {
        LinkedList<Node<T, S>> stack = new LinkedList<Node<T, S>>();
        stack.add(tree.getRoot());
        HashMap nodeMap = new HashMap();
        nodeMap.put(tree.getRoot(), 0);
        int nodeId = 1;
        String sb = "\ndigraph suffixTree{\n node [shape=circle, label=\"\", fixedsize=true, width=0.1, height=0.1]\n";
        while (stack.size() > 0) {
            LinkedList childNodes = new LinkedList();
            for (Node node : stack) {
                for (Edge edge : node) {
                    int id = nodeId++;
                    if (edge.isTerminating()) {
                        childNodes.push(edge.getTerminal());
                        nodeMap.put(edge.getTerminal(), id);
                    }
                    sb = String.valueOf(sb) + nodeMap.get(node) + " -> " + id + " [label=\"";
                    for (Object item : edge) {
                        sb = String.valueOf(sb) + item.toString();
                    }
                    sb = String.valueOf(sb) + "\"];\n";
                }
            }
            stack = childNodes;
        }
        if (printSuffixLinks) {
            sb = String.valueOf(sb) + "edge [color=red]\n";
            for (Map.Entry entry : nodeMap.entrySet()) {
                Node n1 = (Node)entry.getKey();
                int id1 = (Integer)entry.getValue();
                if (!n1.hasSuffixLink()) continue;
                Node n2 = n1.getSuffixLink();
                Integer id2 = (Integer)nodeMap.get(n2);
                sb = String.valueOf(sb) + id1 + " -> " + id2 + " ;\n";
            }
        }
        sb = String.valueOf(sb) + "}";
        return sb;
    }
}

