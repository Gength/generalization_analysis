package m9;
import org.deckfour.xes.model.XLog;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import au.unimelb.negativeEventsClasses.PetrinetLogMapper;
import au.unimelb.evaluation.NegativeEventsTask;
import au.qut.apromore.importer.ImportProcessModel;
import au.qut.apromore.importer.ImportEventLog;

public class M9Diag {
    public static void main(String[] a) throws Exception {
        String logPath=a[0], modelPath=a[1], label=a[2];
        Object[] pm = new ImportProcessModel().importPetriNetAndMarking(modelPath);
        Petrinet net=(Petrinet)pm[0]; Marking marking=(Marking)pm[1];
        XLog log = new ImportEventLog().importEventLog(logPath);
        int nt = net.getTransitions().size();
        StringBuilder sb=new StringBuilder("M9DIAG\t"+label+"\ttransitions="+nt);
        for (String metric : new String[]{"recall","precision","generalization"}) {
            PetrinetLogMapper mapper = PetrinetLogMapper.getStandardMap(log, net);
            double v = NegativeEventsTask.getMetricValue(log, net, marking, mapper, 0,0,true,false,false,-1,-1,true,true,true,false, metric);
            sb.append("\t"+metric+"="+String.format("%.4f",v));
        }
        System.out.println(sb.toString());
    }
}
