# Cap-bump pass: retry only the proper-SDFA cells that failed at cap=20000,
# now at cap=150000 with a 900s per-cell alarm. D1 first (report-consistency).
# Truly unbounded nets still fail (they hit any cap); borderline ones recover.
import os, sys, json, time, math, signal
from collections import Counter, defaultdict
H = os.path.expanduser("~/genbench")
sys.path.insert(0, H)
import pm4py
from pm4py.objects.petri_net.importer import importer as pnml_importer
from pm4py.objects.petri_net import semantics as _sem

CAP = 150000
ALARM = 900
IN = os.path.expanduser("~/m3_rebuild/m3_rebuild.json")
OUT = os.path.expanduser("~/m3_rebuild/m3_capbump.json")

def freeze(m): return frozenset((p, c) for p, c in m.items() if c > 0)

def reachability(net, im, cap):
    start = freeze(im); edges = defaultdict(list); seen = {start}; stack = [im]
    while stack:
        m = stack.pop(); fm = freeze(m)
        if fm in edges: continue
        for t in _sem.enabled_transitions(net, m):
            m2 = _sem.execute(t, net, m)
            if m2 is None: continue
            f2 = freeze(m2); edges[fm].append((t.label, f2))
            if f2 not in seen:
                seen.add(f2); stack.append(m2)
                if len(seen) > cap: raise ValueError(f"exceeds {cap} markings")
    return start, edges

def eps_closure(ms, edges):
    clo = set(ms); st = list(ms)
    while st:
        m = st.pop()
        for lbl, m2 in edges.get(m, ()):
            if lbl is None and m2 not in clo: clo.add(m2); st.append(m2)
    return frozenset(clo)

def determinize(start, edges, dcap=150000):
    s0 = eps_closure({start}, edges); ids = {s0: 0}; order = [s0]; dtrans = {}; i = 0
    while i < len(order):
        S = order[i]; sid = ids[S]; by = defaultdict(set)
        for m in S:
            for lbl, m2 in edges.get(m, ()):
                if lbl is not None: by[lbl].add(m2)
        for lbl, tgts in by.items():
            T = eps_closure(tgts, edges)
            if T not in ids:
                ids[T] = len(order); order.append(T)
                if len(order) > dcap: raise ValueError(f"determinize exceeds {dcap}")
            dtrans[(sid, lbl)] = ids[T]
        i += 1
    return dtrans

def build_and_score(net, im, fm, variants, total, A, cap):
    start, edges = reachability(net, im, cap)
    dtrans = determinize(start, edges)
    cnt = defaultdict(Counter)
    for v, c in variants.items():
        s = 0; ok = True
        for a in v:
            nxt = dtrans.get((s, a))
            if nxt is None: ok = False; break
            cnt[s][a] += c; s = nxt
        if ok: cnt[s]["__STOP__"] += c
    tm, outs = {}, {}
    for s in cnt:
        tot = sum(cnt[s].values())
        for a, c in cnt[s].items():
            if a == "__STOP__": continue
            tm[(s, a)] = (dtrans[(s, a)], c / tot)
            outs[s] = outs.get(s, 0.0) + c / tot
    fit = 0; parsed = []
    for v, c in variants.items():
        s, ok, lp = 0, True, 0.0
        for a in v:
            k = (s, a)
            if k not in tm: ok = False; break
            nxt, p = tm[k]; lp += math.log2(p); s = nxt
        if ok: lp += math.log2(max(1.0 - outs.get(s, 0.0), 1e-12)); fit += c
        parsed.append((c, ok, lp, len(v)))
    rho = fit / total; E = 0.0
    for c, ok, lp, n in parsed:
        w = c / total
        E += w * ((-math.log2(rho) if rho > 0 else 0.0) - lp if ok
                  else (-math.log2(1 - rho) if rho < 1 else 0.0) + (n + 1) * math.log2(A + 1))
    return E, len(edges)

class TO(Exception): pass
signal.signal(signal.SIGALRM, lambda s, f: (_ for _ in ()).throw(TO()))

LOGS = {
 'D1': 'data/Sepsis Cases - Event Log_1_all/Sepsis Cases - Event Log.xes.gz',
 'D2': 'data/BPI-Challenge_2013/Incident_Management_Log.xes.gz',
 'D3': 'data/BPI-Challenge_2017/BPI Challenge 2017.xes.gz',
 'D4': 'data/BPI-Challenge_2018/BPI Challenge 2018.xes.gz',
 'D5': 'data/BPI-Challenge_2019/BPI_Challenge_2019.xes.gz',
}
prev = json.load(open(IN))
todo = defaultdict(list)
for k, row in prev.items():
    ds, mn = k.split("__")
    if row.get("er_proper") is None and "error" not in row:
        todo[ds].append(mn)
order = ['D1', 'D2', 'D3', 'D4', 'D5']
out = {}
for ds in order:
    if not todo.get(ds): continue
    t0 = time.time()
    log = pm4py.convert_to_event_log(pm4py.read_xes(os.path.join(H, LOGS[ds])))
    variants = Counter(tuple(e["concept:name"] for e in t) for t in log)
    total = sum(variants.values()); A = len(set(a for v in variants for a in v))
    print(f"[{ds}] loaded ({time.time()-t0:.0f}s), retrying {todo[ds]}", flush=True)
    for mn in todo[ds]:
        t = time.time(); signal.alarm(ALARM)
        try:
            net, im, fm = pnml_importer.apply(f"{H}/benchmark/models/{ds}/{mn}.pnml")
            E, nmark = build_and_score(net, im, fm, variants, total, A, CAP)
            out[f"{ds}__{mn}"] = {"er_proper": round(E, 3), "markings": nmark,
                                  "cap": CAP, "runtime_s": round(time.time()-t, 1)}
            print(f"  {ds} {mn:22} RECOVERED er={E:.3f} markings={nmark} ({time.time()-t:.0f}s)", flush=True)
        except TO:
            out[f"{ds}__{mn}"] = {"er_proper": None, "note": f"alarm {ALARM}s", "cap": CAP}
            print(f"  {ds} {mn:22} TIMEOUT {ALARM}s", flush=True)
        except Exception as e:
            out[f"{ds}__{mn}"] = {"er_proper": None, "note": str(e)[:60], "cap": CAP}
            print(f"  {ds} {mn:22} still fails: {str(e)[:60]} ({time.time()-t:.0f}s)", flush=True)
        finally:
            signal.alarm(0)
        json.dump(out, open(OUT, "w"), indent=2)
print("CAPBUMP_DONE", flush=True)
