#!/bin/bash
# Self-sufficiency audit pack (cibox). Everything writes under ~/audit_rerun / ~/audit_pull.
mkdir -p ~/audit_rerun ~/audit_pull
PY=~/genbench/.venv/bin/python

# 1) M7 special4pm version forensics (current version + install mtime)
{ echo "== pip show special4pm =="; ~/genbench/.venv/bin/pip show special4pm 2>&1;
  echo "== site-packages mtimes =="; ls -la ~/genbench/.venv/lib/python*/site-packages/ 2>/dev/null | grep -i special;
  echo "== venv created =="; stat -c '%y %n' ~/genbench/.venv/pyvenv.cfg 2>/dev/null;
} > ~/audit_rerun/m7_forensics.txt 2>&1

# 2) hunt for the ORIGINAL M6original(-bgen) D4 run logs (failure semantics of the three 0.0 cells)
{ echo "== bgen-ish files in genbench =="; find ~/genbench -iname "*bgen*" -not -path "*/.git/*" 2>/dev/null | head -50;
  echo "== recent job/log dirs in HOME =="; ls -dlt ~/*/ 2>/dev/null | head -15;
  echo "== M6 mentions in /tmp =="; find /tmp -iname "*m6*" -o -iname "*bgen*" 2>/dev/null | head -20;
} > ~/audit_rerun/bgen_log_search.txt 2>&1

# 3) archive the scored models + m4/m8 raw outputs for the repo
tar czf ~/audit_pull/models.tgz -C ~/genbench/benchmark models 2> ~/audit_rerun/tar_models.err
for d in m8_run m45_run m4_run; do
  [ -d ~/$d ] && tar czf ~/audit_pull/${d}_raw.tgz -C ~ $d 2>> ~/audit_rerun/tar_raw.err
done
ls -la ~/audit_pull > ~/audit_rerun/pull_manifest.txt 2>&1

# 4) rerun the three zero-score D4 Entropia -bgen cells with full output capture
cd ~/genbench/benchmark/bridges
nohup $PY run_m6_bgen.py --dataset D4 --miners Alpha Heuristics_Strict Inductive_Strict \
  --output ~/audit_rerun/m6bgen_d4 > ~/audit_rerun/m6bgen_d4.log 2>&1 &
echo "m6bgen rerun pid $!" > ~/audit_rerun/pids.txt

# 5) replay-drift measurement: 5 fresh processes, D4, Trace_Filtered + Alpha+
nohup bash -c 'for i in 1 2 3 4 5; do PYTHONHASHSEED=0 ~/genbench/.venv/bin/python ~/audit_rerun/drift_cell.py; done' \
  > ~/audit_rerun/drift_d4.jsonl 2> ~/audit_rerun/drift_d4.err &
echo "drift pid $!" >> ~/audit_rerun/pids.txt
echo "AUDIT PACK LAUNCHED"
