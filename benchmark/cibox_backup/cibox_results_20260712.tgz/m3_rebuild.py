# Independent M3 (entropic relevance), pure Python, no Java. ER validated to 3
# decimals vs the real Entropia tool (Exp5 D1). SDFA builder inlined (self-contained).
import os, sys, json, time, math
from collections import Counter, defaultdict
H = os.path.expanduser("~/genbench")
sys.path.insert(0, H); sys.path.insert(0, H + "/benchmark")
import pm4py
from pm4py.objects.petri_net.importer import importer as pnml_importer
from pm4py.objects.petri_net import semantics as _sem

def _enabled(net, m): return _sem.enabled_transitions(net, m)
def _fire(t, net, m): return _sem.execute(t, net, m)
def freeze(m): return frozenset((p, c) for p, c in m.items() if c > 0)

def reachability(net, im, cap=20000):
    start = freeze(im); edges = defaultdict(list); seen = {start}; stack = [im]
    while stack:
        m = stack.pop(); fm = freeze(m)
        if fm in edges: continue
        for t in _enabled(net, m):
            m2 = _fire(t, net, m)
            if m2 is None: continue
            f2 = freeze(m2); edges[fm].append((t.label, f2))
            if f2 not in seen:
                seen.add(f2); stack.append(m2)
                if len(seen) > cap: raise ValueError(f"exceeds {cap} markings (unbounded?)")
    return start, edges

def eps_closure(markings, edges):
    clo = set(markings); stack = list(markings)
    while stack:
        m = stack.pop()
        for lbl, m2 in edges.get(m, ()):
            if lbl is None and m2 not in clo: clo.add(m2); stack.append(m2)
    return frozenset(clo)

def determinize(start, edges):
    s0 = eps_closure({start}, edges); ids = {s0: 0}; order = [s0]; dtrans = {}; i = 0
    while i < len(order):
        S = order[i]; sid = ids[S]; by = defaultdict(set)
        for m in S:
            for lbl, m2 in edges.get(m, ()):
                if lbl is not None: by[lbl].add(m2)
        for lbl, tgts in by.items():
            T = eps_closure(tgts, edges)
            if T not in ids: ids[T] = len(order); order.append(T)
            dtrans[(sid, lbl)] = ids[T]
        i += 1
    return dtrans, len(order)

def build_sdfa(net, im, fm, log, cap=20000):
    start, edges = reachability(net, im, cap); dtrans, _ = determinize(start, edges)
    cnt = defaultdict(Counter)
    for trace in log:
        s = 0; ok = True
        for e in trace:
            a = e["concept:name"]; nxt = dtrans.get((s, a))
            if nxt is None: ok = False; break
            cnt[s][a] += 1; s = nxt
        if ok: cnt[s]["__STOP__"] += 1
    trans = []
    for s in sorted(cnt):
        tot = sum(cnt[s].values())
        if tot == 0: continue
        for a, c in cnt[s].items():
            if a != "__STOP__": trans.append({"from": s, "to": dtrans[(s, a)], "label": a, "prob": c / tot})
    return {"initialState": 0, "transitions": trans}, len(cnt)

def dfg_to_sdfa(net, im, fm, n=5000):
    sim = pm4py.play_out(net, im, fm, no_traces=n)
    df, starts, ends = Counter(), Counter(), Counter()
    for t in sim:
        acts = [e["concept:name"] for e in t]
        if not acts: continue
        starts[acts[0]] += 1; ends[acts[-1]] += 1
        for a, b in zip(acts, acts[1:]): df[(a, b)] += 1
    allacts = sorted(set([a for a, _ in df] + [b for _, b in df] + list(starts) + list(ends)))
    sid = {a: i + 1 for i, a in enumerate(allacts)}; trans = []
    ts = sum(starts.values()) or 1
    for a, c in starts.items(): trans.append({"from": 0, "to": sid[a], "label": a, "prob": c / ts})
    for a in allacts:
        out = sum(df.get((a, b), 0) for b in allacts) + ends.get(a, 0)
        if out == 0: continue
        for b in allacts:
            c = df.get((a, b), 0)
            if c > 0: trans.append({"from": sid[a], "to": sid[b], "label": b, "prob": c / out})
    return {"initialState": 0, "transitions": trans}

def er(sdfa, variants, total, A):
    tm, outs = {}, {}
    for tr in sdfa["transitions"]:
        tm[(tr["from"], tr["label"])] = (tr["to"], tr["prob"])
        outs[tr["from"]] = outs.get(tr["from"], 0.0) + tr["prob"]
    s0 = sdfa["initialState"]; fit = 0; parsed = []
    for v, c in variants.items():
        s, ok, lp = s0, True, 0.0
        for a in v:
            k = (s, a)
            if k not in tm: ok = False; break
            nxt, p = tm[k]; lp += math.log2(p); s = nxt
        if ok: lp += math.log2(max(1.0 - outs.get(s, 0.0), 1e-12)); fit += c
        parsed.append((c, ok, lp, len(v)))
    rho = fit / total; E = 0.0
    for c, ok, lp, n in parsed:
        w = c / total
        E += w * ((-math.log2(rho) if rho > 0 else 0.0) - lp if ok
                  else (-math.log2(1 - rho) if rho < 1 else 0.0) + (n + 1) * math.log2(A + 1))
    return E, rho

LOGS = {
 'D1': 'data/Sepsis Cases - Event Log_1_all/Sepsis Cases - Event Log.xes.gz',
 'D2': 'data/BPI-Challenge_2013/Incident_Management_Log.xes.gz',
 'D3': 'data/BPI-Challenge_2017/BPI Challenge 2017.xes.gz',
 'D4': 'data/BPI-Challenge_2018/BPI Challenge 2018.xes.gz',
 'D5': 'data/BPI-Challenge_2019/BPI_Challenge_2019.xes.gz',
}
MINERS = ['Alpha','Alpha+','Heuristics','Heuristics_Strict','Inductive_Infrequent','Inductive_Strict','Trace_Filtered','Flower']
OUT = os.path.expanduser("~/m3_rebuild"); os.makedirs(OUT, exist_ok=True)

results = {}
for key, lp in LOGS.items():
    t0 = time.time()
    log = pm4py.convert_to_event_log(pm4py.read_xes(os.path.join(H, lp)))
    variants = Counter(tuple(e["concept:name"] for e in t) for t in log)
    total = sum(variants.values()); A = len(set(a for v in variants for a in v))
    print(f"[{key}] {total} traces, {len(variants)} variants, A={A} ({time.time()-t0:.0f}s)", flush=True)
    for mn in MINERS:
        p = f"{H}/benchmark/models/{key}/{mn}.pnml"; row = {}; t = time.time()
        try: net, im, fm = pnml_importer.apply(p)
        except Exception as e: results[f"{key}__{mn}"] = {"error": f"pnml:{e}"}; continue
        try:
            sdfa_p, nst = build_sdfa(net, im, fm, log, 20000)
            row["er_proper"] = round(er(sdfa_p, variants, total, A)[0], 3); row["proper_states"] = nst
        except Exception as e: row["er_proper"] = None; row["proper_note"] = str(e)[:45]
        try:
            ed, rd = er(dfg_to_sdfa(net, im, fm), variants, total, A)
            row["er_dfg"] = round(ed, 3); row["rho_dfg"] = round(rd, 3)
        except Exception as e: row["er_dfg"] = None; row["dfg_note"] = str(e)[:45]
        row["runtime_s"] = round(time.time() - t, 1); results[f"{key}__{mn}"] = row
        json.dump(results, open(f"{OUT}/m3_rebuild.json", "w"), indent=2)
        print(f"  {key} {mn:22} proper={row.get('er_proper')} dfg={row.get('er_dfg')} ({row['runtime_s']}s)", flush=True)
print("M3_REBUILD_DONE", flush=True)
